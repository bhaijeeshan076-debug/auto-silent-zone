package com.autosilentzone

import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

/** Qibla: Kaaba ki disha. Phone ko seedha (flat) rakho, sunehri teer Qibla ki taraf jayega. */
class QiblaActivity : ComponentActivity(), SensorEventListener {
    private var heading by mutableStateOf<Float?>(null)
    private var loc by mutableStateOf<Pair<Double, Double>?>(null)
    private var declination = 0f
    private lateinit var sm: SensorManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        val s = Store(this)
        if (s.hasLocation) setLoc(s.lat, s.lng)
        fetchLocation(this) { la, lo -> setLoc(la, lo) }
        setContent { MaterialTheme { Screen() } }
    }

    private fun setLoc(la: Double, lo: Double) {
        declination = GeomagneticField(la.toFloat(), lo.toFloat(), 0f, System.currentTimeMillis()).declination
        loc = la to lo
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onPause() {
        super.onPause()
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        val r = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(r, e.values)
        val o = FloatArray(3)
        SensorManager.getOrientation(r, o)
        val az = (((Math.toDegrees(o[0].toDouble()).toFloat() + declination) % 360f) + 360f) % 360f
        val old = heading
        heading = if (old == null) az else {
            var d = az - old
            if (d > 180f) d -= 360f
            if (d < -180f) d += 360f
            ((old + d * 0.2f) + 360f) % 360f
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @Composable
    fun Screen() {
        val l = loc
        Column(
            Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
        ) {
            Text(tr("Qibla", "क़िब्ला", "Qibla"), style = MaterialTheme.typography.headlineSmall)
            if (l == null) {
                Text(tr("Location not found. Allow location in Setup and turn on GPS.",
                    "लोकेशन नहीं मिली। सेटअप में अनुमति दें और GPS चालू करें।",
                    "Location nahi mili. Setup mein permission do aur GPS on karo."), textAlign = TextAlign.Center)
            } else {
                val q = Astro.qiblaBearing(l.first, l.second)
                Text(tr("Qibla is ${q.roundToInt()}\u00B0 from North", "क़िब्ला उत्तर से ${q.roundToInt()}\u00B0 पर है", "Qibla North se ${q.roundToInt()}\u00B0 par hai"),
                    style = MaterialTheme.typography.titleMedium)
                if (heading != null) {
                    Compass(q, heading)
                    Text(tr("Hold the phone flat. The golden arrow points to the Qibla.",
                        "फ़ोन को सीधा (flat) पकड़ें। सुनहरा तीर क़िब्ला की ओर है।",
                        "Phone ko seedha (flat) pakdo. Sunehra teer Qibla ki taraf hai."), textAlign = TextAlign.Center)
                } else {
                    Text(tr("Compass sensor not available. Use the angle above with any compass.",
                        "कंपास सेंसर नहीं मिला। ऊपर का कोण किसी भी कंपास के साथ इस्तेमाल करें।",
                        "Compass sensor nahi mila. Upar wala angle kisi bhi compass ke saath use karo."), textAlign = TextAlign.Center)
                }
            }
        }
    }

    @Composable
    private fun Compass(qibla: Double, heading: Float?) {
        val gold = Color(0xFFD4AF37)
        val h = heading ?: 0f
        Canvas(Modifier.size(280.dp)) {
            val c = center
            val r = size.minDimension / 2
            drawCircle(gold.copy(alpha = 0.4f), r - 4.dp.toPx(), c, style = Stroke(3.dp.toPx()))
            rotate(-h, c) {
                drawLine(Color.Gray, Offset(c.x, c.y - r + 4.dp.toPx()), Offset(c.x, c.y - r + 24.dp.toPx()), 5.dp.toPx())
            }
            val angle = (qibla - h).toFloat()
            rotate(angle, c) {
                drawLine(gold, c, Offset(c.x, c.y - r + 34.dp.toPx()), 8.dp.toPx(), StrokeCap.Round)
                drawCircle(gold, 12.dp.toPx(), Offset(c.x, c.y - r + 34.dp.toPx()))
            }
            drawCircle(gold, 6.dp.toPx(), c)
        }
    }
}
