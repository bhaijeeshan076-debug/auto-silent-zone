package com.autosilentzone

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0B0B0D)
private val CardBg = Color(0xFF16151A)
private val Gold = Color(0xFFD4AF37)
private val Cream = Color(0xFFF3E2B3)
private val Ink = Color(0xFFEDE7D6)
private val Muted = Color(0xFFA39A80)
private val Green = Color(0xFF3DDC97)

/** Naya premium home page: dial + zone chips + feature cards + pin spot. */
@Composable
fun HomeScreen(store: Store, tick: Int, onSetup: () -> Unit, onNearby: () -> Unit, onPrayer: () -> Unit, onPin: (String) -> Unit) {
    val zones = remember(tick) { store.zones() }
    val active = store.activeZone
    val favCount = store.favourites().size
    var showPin by remember { mutableStateOf(false) }
    var pinName by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("AUTO SILENT ZONE", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp)
        Text(tr("Pack: ","पैक: ","Pack: ") + FaithPacks.selected(store).joinToString { "${it.name()} (${it.place()})" }, color = Muted, fontSize = 12.sp)

        Dial(
            active = active != null,
            title = if (active != null) tr("SILENT ON","साइलेंट चालू","SILENT ON") else tr("RING MODE","रिंग मोड","RING MODE"),
            sub = active ?: tr("No zone active","कोई ज़ोन चालू नहीं है","Koi zone active nahi")
        )

        // Zone chips
        if (zones.isEmpty()) {
            Text(tr("No zones yet. Tap + PIN SPOT below or search nearby places.","अभी कोई ज़ोन नहीं है। नीचे + PIN SPOT दबाएँ या पास की जगह खोजें।","Abhi koi zone nahi. Neeche + PIN SPOT dabao ya paas ki jagah dhundo."), color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                zones.forEach { z ->
                    val sel = z.name == active
                    val m = if (sel) Modifier.background(Brush.horizontalGradient(listOf(Cream, Gold))) else Modifier.border(1.dp, Gold.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
                    Column(
                        Modifier.clip(RoundedCornerShape(26.dp)).then(m).padding(horizontal = 18.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(z.name, color = if (sel) Color(0xFF1A1405) else Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                        Text("${z.radius.toInt()}m", color = if (sel) Color(0xFF3A2D0A) else Muted, fontSize = 12.sp)
                    }
                }
            }
        }

        // Feature cards
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("REPEAT CALL", "${store.threshold} call pe ring", tr("ON","चालू","ON"), Modifier.weight(1f))
            FeatureCard("FAVOURITES", tr("VIP bypass","VIP को छूट","VIP bypass"), "$favCount CONTACTS", Modifier.weight(1f))
        }

        // Saved zones + pin
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
                .border(1.dp, Gold.copy(alpha = 0.25f), RoundedCornerShape(20.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(active ?: zones.firstOrNull()?.name ?: tr("No zones","कोई ज़ोन नहीं","Koi zone nahi"), color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                Text("${zones.size} Saved Zones \u00B7 Auto-Arm", color = Muted, fontSize = 12.sp)
            }
            Button(
                onClick = { showPin = true },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color(0xFF1A1405))
            ) { Text("+ PIN SPOT", fontWeight = FontWeight.Bold) }
        }

        if ("islam" in store.faiths) {
            OutlinedButton(onClick = onPrayer, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Gold),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)) { Text(tr("Prayer times","नमाज़ के वक़्त","Namaz ke waqt")) }
        }

        // Jin dharmon ke timings abhi nahi bane, unke liye saaf likha rahe
        if (FaithPacks.selected(store).any { it.id != "islam" && it.id != "custom" }) {
            Text(
                tr("Timings and festivals for your faith are coming soon.", "आपके धर्म के समय और त्योहार जल्द आ रहे हैं।", "Aapke dharm ke timings aur tyohaar jald aa rahe hain."),
                color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onNearby, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, Gold),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)) { Text(nearbyLabel(store)) }
            OutlinedButton(onClick = onSetup, modifier = Modifier.weight(1f), border = BorderStroke(1.dp, Gold),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cream)) { Text(tr("Setup","सेटअप","Setup")) }
        }
    }

    if (showPin) {
        AlertDialog(
            onDismissRequest = { showPin = false },
            title = { Text(tr("Name of this place","इस जगह का नाम","Is jagah ka naam")) },
            text = { OutlinedTextField(pinName, { pinName = it }, singleLine = true, label = { Text(exampleName(store)) }) },
            confirmButton = {
                TextButton(enabled = pinName.isNotBlank(), onClick = { onPin(pinName); pinName = ""; showPin = false }) { Text("Pin karo") }
            },
            dismissButton = { TextButton(onClick = { showPin = false }) { Text(tr("Cancel","रद्द करें","Cancel")) } }
        )
    }
}

@Composable
private fun FeatureCard(label: String, title: String, status: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(CardBg)
            .border(1.dp, Gold.copy(alpha = 0.25f), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(label, color = Gold, fontSize = 11.sp, letterSpacing = 2.sp)
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("\u25CF $status", color = Green, fontSize = 12.sp)
    }
}

@Composable
private fun Dial(active: Boolean, title: String, sub: String) {
    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            val c = center
            drawCircle(
                Brush.sweepGradient(listOf(Gold, Cream, Gold, Color(0xFF8A6D1F), Gold), center = c),
                radius = r - 5.dp.toPx(), style = Stroke(7.dp.toPx())
            )
            drawCircle(Gold.copy(alpha = 0.25f), radius = r - 26.dp.toPx(), style = Stroke(1.dp.toPx()))
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0 - 90.0)
                val long = i % 5 == 0
                val r1 = r - 38.dp.toPx()
                val r2 = r1 - (if (long) 10f else 5f).dp.toPx()
                drawLine(
                    Gold.copy(alpha = if (long) 0.8f else 0.35f),
                    Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                    Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()),
                    strokeWidth = 1.5f.dp.toPx()
                )
            }
            val inset = 15.dp.toPx()
            drawArc(
                Gold, -90f, if (active) 270f else 40f, false,
                topLeft = Offset(inset, inset), size = Size(size.width - 2 * inset, size.height - 2 * inset),
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
            )
            drawCircle(Color(0xFF101013), radius = r - 70.dp.toPx())
        }
        Column(Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (active) "\uD83D\uDD15" else "\uD83D\uDD14", fontSize = 24.sp)
            Text(title, color = Cream, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center)
            Text(sub, color = Gold, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}
