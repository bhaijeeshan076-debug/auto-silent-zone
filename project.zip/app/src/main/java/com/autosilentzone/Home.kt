package com.autosilentzone

import android.app.Activity
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val Green = Color(0xFF3DDC97)

/** Har dharm ka apna rang, apna nishaan aur apna abhivadan. Ek se zyada dharm chune ho to neutral sunehri theme. */
class HomeTheme(
    val bg: Color, val card: Color, val dialFill: Color, val accent: Color, val accent2: Color,
    val cream: Color, val ink: Color, val muted: Color, val onAccent: Color,
    val glyph: String?, val drawn: String?, val greeting: () -> String
)

private fun themeFor(store: Store): HomeTheme {
    val sel = FaithPacks.selected(store).filter { it.id != "custom" }
    return themeForId(if (sel.size == 1) sel[0].id else "default")
}

/** Dharm ki id se uska theme (home page aur dharm chunne wali screen dono isse banate hain). */
fun themeForId(id: String): HomeTheme {
    return when (id) {
        "islam" -> HomeTheme(
            Color(0xFF06130E), Color(0xFF0E2219), Color(0xFF081A13), Color(0xFFD4AF37), Color(0xFF8A6D1F),
            Color(0xFFF1E7C6), Color(0xFFE6F0E8), Color(0xFF8FB09E), Color(0xFF08130E),
            null, "crescent") { tr("Assalamu Alaikum", "अस्सलामु अलैकुम", "Assalamu Alaikum") }
        "hindu" -> HomeTheme(
            Color(0xFF1A0B05), Color(0xFF2A1409), Color(0xFF1E0E07), Color(0xFFFF9933), Color(0xFFB35C00),
            Color(0xFFFFE2B8), Color(0xFFFBE9D5), Color(0xFFC9A27C), Color(0xFF2B1200),
            "\u0950", null) { tr("Namaste", "नमस्ते", "Namaste") }
        "christian" -> HomeTheme(
            Color(0xFF0A1220), Color(0xFF111C30), Color(0xFF0C1627), Color(0xFF9DC1FF), Color(0xFF4A74B8),
            Color(0xFFEAF2FF), Color(0xFFE3ECFA), Color(0xFF8FA6C9), Color(0xFF0A1220),
            null, "cross") { tr("Peace be with you", "आप पर शांति बनी रहे", "Aap par shanti bani rahe") }
        "sikh" -> HomeTheme(
            Color(0xFF0A1330), Color(0xFF121D45), Color(0xFF0C1736), Color(0xFFF5A623), Color(0xFFB87400),
            Color(0xFFFFE9B8), Color(0xFFF2EBD6), Color(0xFFB5B0C9), Color(0xFF1A1000),
            "\u0A74", null) { tr("Sat Sri Akal", "सत श्री अकाल", "Sat Sri Akal") }
        "buddhist" -> HomeTheme(
            Color(0xFF180A10), Color(0xFF291119), Color(0xFF1D0C13), Color(0xFFF2C14E), Color(0xFF9C7A1F),
            Color(0xFFFBE9B8), Color(0xFFF4E8CF), Color(0xFFBFA58A), Color(0xFF1F1500),
            "\u2638", null) { tr("Namo Buddhaya", "नमो बुद्धाय", "Namo Buddhaya") }
        "jain" -> HomeTheme(
            Color(0xFF160C0C), Color(0xFF261414), Color(0xFF1A0E0E), Color(0xFFE8553D), Color(0xFF9C3322),
            Color(0xFFFFE6DF), Color(0xFFF6E4DE), Color(0xFFC49C94), Color(0xFF1A0600),
            "\u0905\u0939\u093F\u0902\u0938\u093E", null) { tr("Jai Jinendra", "जय जिनेन्द्र", "Jai Jinendra") }
        "jewish" -> HomeTheme(
            Color(0xFF08142B), Color(0xFF0F1E3D), Color(0xFF0B1833), Color(0xFFB8D4FF), Color(0xFF4F78C0),
            Color(0xFFF2F7FF), Color(0xFFE6EEFB), Color(0xFF8FA6C9), Color(0xFF08142B),
            null, "star") { tr("Shalom", "शालोम", "Shalom") }
        else -> HomeTheme(
            Color(0xFF0B0B0D), Color(0xFF16151A), Color(0xFF101013), Color(0xFFD4AF37), Color(0xFF8A6D1F),
            Color(0xFFF3E2B3), Color(0xFFEDE7D6), Color(0xFFA39A80), Color(0xFF1A1405),
            null, null) { tr("Welcome", "स्वागत है", "Swagat hai") }
    }
}

/** Dharm ke hisaab se agla waqt: Islam mein agli namaz + Hijri tareekh, baaki mein agla pooja/prarthana waqt. */
private fun faithInfo(s: Store, p: FaithPack): Pair<String, String>? {
    if (!s.hasLocation) return null
    val f = SimpleDateFormat("EEE hh:mm a", Locale.getDefault())
    if (p.id == "islam") {
        val n = PrayerTimes.next(s.lat, s.lng, s.method, s.asr) ?: return null
        val hijri = try { Festivals.hijriText(s) } catch (_: Exception) { "" }
        return (tr("Next prayer: ", "अगली नमाज़: ", "Agli namaz: ") + n.label + "  " + f.format(Date(n.time))) to hijri
    }
    val now = System.currentTimeMillis()
    val next = FaithTimings.upcoming(s, p.id, s.lat, s.lng).filter { it.time > now }.minByOrNull { it.time } ?: return null
    val extra = if (p.id == "hindu") tr("Tithi: ", "तिथि: ", "Tithi: ") + Astro.tithiText(Astro.tithi(now)) else ""
    return (next.label + "  " + f.format(Date(next.time))) to extra
}

@Composable
fun HomeScreen(store: Store, tick: Int, onSetup: () -> Unit, onNearby: () -> Unit, onPrayer: () -> Unit, onManual: () -> Unit, onQibla: () -> Unit, onTimings: () -> Unit, onFestivals: () -> Unit, onPin: (String) -> Unit) {
    val t = themeFor(store)
    val zones = remember(tick) { store.zones() }
    val active = store.activeZone
    val favCount = store.favourites().size

    // Status bar aur navigation bar ka rang bhi dharm ke theme jaisa
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let {
            it.statusBarColor = t.bg.toArgb()
            it.navigationBarColor = t.bg.toArgb()
        }
    }

    Column(
        Modifier.fillMaxSize().background(t.bg).verticalScroll(rememberScrollState())
            .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Text("AUTO SILENT ZONE", color = t.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 3.sp)
        Text(t.greeting(), color = t.cream, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Text(tr("Pack: ", "पैक: ", "Pack: ") + FaithPacks.selected(store).joinToString { "${it.name()} (${it.place()})" }, color = t.muted, fontSize = 12.sp)

        Dial(
            t, active = active != null,
            title = if (active != null) tr("SILENT ON", "साइलेंट चालू", "SILENT ON") else tr("RING MODE", "रिंग मोड", "RING MODE"),
            sub = active ?: tr("No zone active", "कोई ज़ोन चालू नहीं है", "Koi zone active nahi")
        )

        // Dharm ke hisaab se agla waqt
        val packs = FaithPacks.selected(store)
        val infoPacks = packs.filter { it.id != "custom" }
        if (infoPacks.isNotEmpty()) {
            if (!store.hasLocation) {
                Text(
                    tr("Open Timings once so the app can load your location.", "टाइमिंग्स एक बार खोलें ताकि ऐप आपकी लोकेशन ले सके।", "Timings ek baar kholo, taaki app aapki location le sake."),
                    color = t.muted, fontSize = 12.sp, textAlign = TextAlign.Center
                )
            } else {
                infoPacks.forEach { p ->
                    val info = remember(tick, p.id) { try { faithInfo(store, p) } catch (_: Exception) { null } }
                    if (info != null) {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(t.card)
                                .border(1.dp, t.accent.copy(alpha = 0.3f), RoundedCornerShape(18.dp)).padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(p.name().uppercase(), color = t.accent, fontSize = 11.sp, letterSpacing = 2.sp)
                            Text(info.first, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            if (info.second.isNotEmpty()) Text(info.second, color = t.muted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Zone chips
        if (zones.isEmpty()) {
            Text(tr("No zones yet. Tap + ADD ZONE HERE below or search nearby places.", "अभी कोई ज़ोन नहीं है। नीचे + यहाँ ज़ोन जोड़ें दबाएँ या पास की जगह खोजें।", "Abhi koi zone nahi. Neeche + YAHAN ZONE dabao ya paas ki jagah dhundo."), color = t.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
        } else {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                zones.forEach { z ->
                    val sel = z.name == active
                    val m = if (sel) Modifier.background(Brush.horizontalGradient(listOf(t.cream, t.accent))) else Modifier.border(1.dp, t.accent.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
                    Column(
                        Modifier.clip(RoundedCornerShape(26.dp)).then(m).padding(horizontal = 18.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(z.name, color = if (sel) t.onAccent else t.ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                        Text("${z.radius.toInt()}m", color = if (sel) t.onAccent.copy(alpha = 0.75f) else t.muted, fontSize = 12.sp)
                    }
                }
            }
        }

        // Feature cards
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard(t, "REPEAT CALL", "${store.threshold} call pe ring", tr("ON", "चालू", "ON"), Modifier.weight(1f))
            FeatureCard(t, "FAVOURITES", tr("VIP bypass", "VIP को छूट", "VIP bypass"), "$favCount CONTACTS", Modifier.weight(1f))
        }

        // Saved zones + add
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(t.card)
                .border(1.dp, t.accent.copy(alpha = 0.25f), RoundedCornerShape(20.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(active ?: zones.firstOrNull()?.name ?: tr("No zones", "कोई ज़ोन नहीं", "Koi zone nahi"), color = t.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1)
                Text("${zones.size} Saved Zones \u00B7 Auto-Arm", color = t.muted, fontSize = 12.sp)
            }
            Button(
                onClick = { onPin("") },
                colors = ButtonDefaults.buttonColors(containerColor = t.accent, contentColor = t.onAccent)
            ) { Text(tr("+ ADD ZONE HERE", "+ यहाँ ज़ोन जोड़ें", "+ YAHAN ZONE"), fontWeight = FontWeight.Bold) }
        }

        val manualOn = store.manualUntil > System.currentTimeMillis()
        GoldButton(
            t,
            if (manualOn) tr("Manual silent ON - tap to stop", "मैनुअल साइलेंट चालू - बंद करने के लिए दबाएँ", "Manual silent chalu - band karne ke liye dabao")
            else tr("Silent for 1 hour", "1 घंटे के लिए साइलेंट", "Abhi 1 ghante ke liye silent"),
            onManual, Modifier.fillMaxWidth()
        )

        val others = packs.filter { it.id != "islam" && it.id != "custom" }
        if (packs.any { it.id == "islam" }) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GoldButton(t, tr("Prayer times", "नमाज़ के वक़्त", "Namaz ke waqt"), onPrayer, Modifier.weight(1f))
                GoldButton(t, tr("Qibla", "क़िब्ला", "Qibla"), onQibla, Modifier.weight(1f))
            }
        }
        if (others.isNotEmpty()) GoldButton(t, timingsLabel(others), onTimings, Modifier.fillMaxWidth())
        GoldButton(t, tr("Festivals & events", "त्योहार और कार्यक्रम", "Tyohaar aur events"), onFestivals, Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GoldButton(t, nearbyLabel(store), onNearby, Modifier.weight(1f))
            GoldButton(t, tr("Setup", "सेटअप", "Setup"), onSetup, Modifier.weight(1f))
        }
    }
}

@Composable
private fun FeatureCard(t: HomeTheme, label: String, title: String, status: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(t.card)
            .border(1.dp, t.accent.copy(alpha = 0.25f), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(label, color = t.accent, fontSize = 11.sp, letterSpacing = 2.sp)
        Text(title, color = t.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("\u25CF $status", color = Green, fontSize = 12.sp)
    }
}

private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float): Path {
    val p = Path()
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outer else inner
        val a = Math.toRadians(-90.0 + i * 36.0)
        val x = cx + (r * cos(a)).toFloat()
        val y = cy + (r * sin(a)).toFloat()
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

private fun trianglePath(cx: Float, cy: Float, r: Float, up: Boolean): Path {
    val p = Path()
    for (k in 0 until 3) {
        val a = Math.toRadians((if (up) -90.0 else 90.0) + k * 120.0)
        val x = cx + (r * cos(a)).toFloat()
        val y = cy + (r * sin(a)).toFloat()
        if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

/** Dial ke beech ka dharm ka nishaan: chaand-taara, kharosh, Star of David, ya Om/Ik Onkar jaise akshar. */
@Composable
fun Symbol(t: HomeTheme, active: Boolean) {
    when {
        t.glyph != null -> Text(t.glyph, color = t.accent, fontSize = if (t.glyph.length > 2) 20.sp else 28.sp, fontWeight = FontWeight.Bold)
        t.drawn != null -> Canvas(Modifier.size(34.dp)) {
            val w = size.width
            val h = size.height
            when (t.drawn) {
                "crescent" -> {
                    drawCircle(t.accent, w * 0.42f, Offset(w * 0.46f, h * 0.5f))
                    drawCircle(t.dialFill, w * 0.34f, Offset(w * 0.58f, h * 0.44f))
                    drawPath(starPath(w * 0.74f, h * 0.40f, w * 0.12f, w * 0.05f), t.accent)
                }
                "cross" -> {
                    drawRoundRect(t.accent, Offset(w * 0.43f, h * 0.06f), Size(w * 0.14f, h * 0.88f), CornerRadius(2.dp.toPx()))
                    drawRoundRect(t.accent, Offset(w * 0.22f, h * 0.28f), Size(w * 0.56f, h * 0.14f), CornerRadius(2.dp.toPx()))
                }
                "star" -> {
                    val st = Stroke(2.dp.toPx())
                    drawPath(trianglePath(w / 2, h / 2 + 1f, w * 0.46f, true), t.accent, style = st)
                    drawPath(trianglePath(w / 2, h / 2 - 1f, w * 0.46f, false), t.accent, style = st)
                }
            }
        }
        else -> Text(if (active) "\uD83D\uDD15" else "\uD83D\uDD14", fontSize = 24.sp)
    }
}

@Composable
private fun Dial(t: HomeTheme, active: Boolean, title: String, sub: String) {
    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            val c = center
            drawCircle(
                Brush.sweepGradient(listOf(t.accent, t.cream, t.accent, t.accent2, t.accent), center = c),
                radius = r - 5.dp.toPx(), style = Stroke(7.dp.toPx())
            )
            drawCircle(t.accent.copy(alpha = 0.25f), radius = r - 26.dp.toPx(), style = Stroke(1.dp.toPx()))
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0 - 90.0)
                val long = i % 5 == 0
                val r1 = r - 38.dp.toPx()
                val r2 = r1 - (if (long) 10f else 5f).dp.toPx()
                drawLine(
                    t.accent.copy(alpha = if (long) 0.8f else 0.35f),
                    Offset(c.x + (r1 * cos(a)).toFloat(), c.y + (r1 * sin(a)).toFloat()),
                    Offset(c.x + (r2 * cos(a)).toFloat(), c.y + (r2 * sin(a)).toFloat()),
                    strokeWidth = 1.5f.dp.toPx()
                )
            }
            val inset = 15.dp.toPx()
            drawArc(
                t.accent, -90f, if (active) 270f else 40f, false,
                topLeft = Offset(inset, inset), size = Size(size.width - 2 * inset, size.height - 2 * inset),
                style = Stroke(5.dp.toPx(), cap = StrokeCap.Round)
            )
            drawCircle(t.dialFill, radius = r - 70.dp.toPx())
        }
        Column(Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Symbol(t, active)
            Text(title, color = t.cream, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 2.sp, textAlign = TextAlign.Center)
            Text(sub, color = t.accent, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
private fun GoldButton(t: HomeTheme, text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick, modifier = modifier, border = BorderStroke(1.dp, t.accent),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = t.cream)
    ) { Text(text) }
}
