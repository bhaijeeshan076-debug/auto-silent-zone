package com.autosilentzone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Zone(val id: String, val name: String, val lat: Double, val lng: Double, val radius: Float = 75f)

/** Sab data sirf phone mein (SharedPreferences). Server pe kuch nahi jata. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("asz", Context.MODE_PRIVATE)

    fun zones(): List<Zone> {
        val arr = JSONArray(p.getString("zones", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Zone(o.getString("id"), o.getString("name"), o.getDouble("lat"), o.getDouble("lng"), o.getDouble("r").toFloat())
        }
    }
    fun saveZones(z: List<Zone>) {
        val arr = JSONArray()
        z.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lng", it.lng).put("r", it.radius.toDouble())) }
        p.edit().putString("zones", arr.toString()).apply()
    }

    var threshold: Int get() = p.getInt("threshold", 5); set(v) = p.edit().putInt("threshold", v).apply()
    var windowMin: Int get() = p.getInt("window", 15); set(v) = p.edit().putInt("window", v).apply()

    var faiths: Set<String>
        get() = p.getStringSet("faiths", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("faiths", v).apply()

    // Silent state
    var activeZone: String? get() = p.getString("active", null); set(v) = p.edit().putString("active", v).apply()
    var savedRinger: Int get() = p.getInt("saved", -1); set(v) = p.edit().putInt("saved", v).apply()

    // Favourite numbers (hashed)
    fun favourites(): Set<String> = p.getStringSet("fav", emptySet()) ?: emptySet()
    fun addFavourite(number: String) = p.edit().putStringSet("fav", favourites() + hash(number)).apply()

    // Call counter: {numberHash: [timestamps]}
    fun recordCall(number: String, now: Long): Int {
        val h = hash(number)
        val cutoff = now - windowMin * 60_000L
        val list = (p.getString("c_$h", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.filter { it > cutoff } + now
        p.edit().putString("c_$h", list.joinToString(",")).apply()
        return list.size
    }
    fun resetCounters() {
        val e = p.edit(); p.all.keys.filter { it.startsWith("c_") }.forEach { e.remove(it) }; e.apply()
    }

    companion object {
        fun hash(n: String): String =
            MessageDigest.getInstance("SHA-256").digest(n.filter { it.isDigit() }.takeLast(10).toByteArray())
                .joinToString("") { "%02x".format(it) }
    }
}
