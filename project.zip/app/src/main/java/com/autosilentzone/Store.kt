package com.autosilentzone

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/** mode: 0 = Silent, 1 = Vibrate, 2 = DND. respect = media volume bhi 0 karo. */
data class Zone(
    val id: String, val name: String, val lat: Double, val lng: Double,
    val radius: Float = 75f, val mode: Int = 0, val respect: Boolean = true
)

/** Sab data sirf phone mein (SharedPreferences). Server pe kuch nahi jata. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("asz", Context.MODE_PRIVATE)

    private fun readList(key: String): List<Zone> {
        val arr = JSONArray(p.getString(key, "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Zone(
                o.getString("id"), o.getString("name"), o.getDouble("lat"), o.getDouble("lng"),
                o.optDouble("r", 75.0).toFloat(), o.optInt("mode", 0), o.optBoolean("respect", true)
            )
        }
    }
    private fun writeList(key: String, z: List<Zone>) {
        val arr = JSONArray()
        z.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("lat", it.lat).put("lng", it.lng)
                .put("r", it.radius.toDouble()).put("mode", it.mode).put("respect", it.respect))
        }
        p.edit().putString(key, arr.toString()).apply()
    }

    fun zones(): List<Zone> = readList("zones")
    fun saveZones(z: List<Zone>) = writeList("zones", z)

    // Favourite jagahein (mandir/masjid/church...)
    fun favPlaces(): List<Zone> = readList("favplaces")
    fun saveFavPlaces(z: List<Zone>) = writeList("favplaces", z)

    var threshold: Int get() = p.getInt("threshold", 5); set(v) = p.edit().putInt("threshold", v).apply()
    var windowMin: Int get() = p.getInt("window", 15); set(v) = p.edit().putInt("window", v).apply()

    var faiths: Set<String>
        get() = p.getStringSet("faiths", emptySet()) ?: emptySet()
        set(v) = p.edit().putStringSet("faiths", v).apply()

    // Silent state
    var activeZone: String? get() = p.getString("active", null); set(v) = p.edit().putString("active", v).apply()
    var activeMode: Int get() = p.getInt("amode", 0); set(v) = p.edit().putInt("amode", v).apply()
    var activeRespect: Boolean get() = p.getBoolean("arespect", false); set(v) = p.edit().putBoolean("arespect", v).apply()
    var savedRinger: Int get() = p.getInt("saved", -1); set(v) = p.edit().putInt("saved", v).apply()
    var savedFilter: Int get() = p.getInt("savedf", -1); set(v) = p.edit().putInt("savedf", v).apply()
    var savedMusic: Int get() = p.getInt("savedm", -1); set(v) = p.edit().putInt("savedm", v).apply()

    // Zaroori contacts (number hash hokar), naam alag
    fun favourites(): Set<String> = p.getStringSet("fav", emptySet()) ?: emptySet()
    fun favNames(): Map<String, String> {
        val o = JSONObject(p.getString("favnames", "{}"))
        return o.keys().asSequence().associateWith { o.getString(it) }
    }
    fun addFavourite(name: String, number: String) {
        if (number.filter { it.isDigit() }.length < 5) return
        val h = hash(number)
        p.edit().putStringSet("fav", favourites() + h)
            .putString("favnames", JSONObject(favNames() + (h to name)).toString()).apply()
    }
    fun removeFavourite(h: String) {
        p.edit().putStringSet("fav", favourites() - h)
            .putString("favnames", JSONObject(favNames() - h).toString()).apply()
    }

    // Call counter: {numberHash: [timestamps]}
    fun recordCall(number: String, now: Long): Int {
        val h = hash(number)
        val cutoff = now - windowMin * 60_000L
        val list = (p.getString("c_$h", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.filter { it > cutoff } + now
        p.edit().putString("c_$h", list.joinToString(",")).apply()
        return list.size
    }
    fun resetCounters() {
        val e = p.edit(); p.all.keys.filter { it.startsWith("c_") }.forEach { e.remove(it) }; e.apply()
    }

    companion object {
        fun hash(n: String): String =
            MessageDigest.getInstance("SHA-256").digest(n.filter { it.isDigit() }.takeLast(10).toByteArray())
                .joinToString("") { "%02x".format(it) }
    }
}
