package com.autosilentzone

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Core app kisi dharm ka nahi. Har dharm ek "pack" hai. Naya dharm = list mein ek nayi line. */
data class FaithPack(val id: String, val label: String, val placeName: String, val osmTag: String?)

object FaithPacks {
    val all = listOf(
        FaithPack("islam", "Islam", "Masjid", "muslim"),
        FaithPack("hindu", "Hindu", "Mandir", "hindu"),
        FaithPack("christian", "Christian", "Church", "christian"),
        FaithPack("sikh", "Sikh", "Gurudwara", "sikh"),
        FaithPack("buddhist", "Buddhist", "Vihara", "buddhist"),
        FaithPack("jain", "Jain", "Derasar", "jain"),
        FaithPack("jewish", "Jewish", "Synagogue", "jewish"),
        FaithPack("custom", "Custom", "Meri jagah", null),
    )
    fun selected(store: Store) = all.filter { it.id in store.faiths }
}

/** Pehli baar kholne pe: dharm chuno (ek ya zyada). Koi default nahi, koi dharm pehle nahi. */
@Composable
fun Onboarding(store: Store, onDone: () -> Unit) {
    var chosen by remember { mutableStateOf(setOf<String>()) }
    Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Aap kaun si jagah ke liye use karoge?", style = MaterialTheme.typography.headlineSmall)
        Text("Ek ya zyada chuno. Baad mein badal sakte ho.")
        FaithPacks.all.forEach { p ->
            Row(Modifier.fillMaxWidth()) {
                Checkbox(checked = p.id in chosen, onCheckedChange = {
                    chosen = if (it) chosen + p.id else chosen - p.id
                })
                Text("${p.label} (${p.placeName})", Modifier.align(androidx.compose.ui.Alignment.CenterVertically))
            }
        }
        Spacer(Modifier.weight(1f))
        Button(enabled = chosen.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
            onClick = { store.faiths = chosen; onDone() }) { Text("Aage badho") }
    }
}
