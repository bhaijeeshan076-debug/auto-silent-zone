package com.autosilentzone

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Core app kisi dharm ka nahi. Har dharm ek "pack" hai. Naya dharm = list mein ek nayi line. */
data class FaithPack(val id: String, val label: String, val placeName: String, val osmTag: String?)

object FaithPacks {
    val all = listOf(
        FaithPack("islam", "Islam", "Masjid", "muslim"),
        FaithPack("hindu", "Hindu", "Mandir", "hindu"),
        FaithPack("christian", "Christian", "Church", "christian"),
        FaithPack("sikh", "Sikh", "Gurudwara", "sikh"),
        FaithPack("buddhist", "Buddhist", "Vihara", "buddhist"),
        FaithPack("jain", "Jain", "Derasar", "jain"),
        FaithPack("jewish", "Jewish", "Synagogue", "jewish"),
        FaithPack("custom", "Custom", "Meri jagah", null),
    )
    fun selected(store: Store) = all.filter { it.id in store.faiths }
}

/**
 * Pehli screen: pehle apna dharm chuno. Ek card dabate hi us dharm ka home page khul jata hai.
 * Ek se zyada dharm chahiye to neeche wala link dabao. Koi dharm default nahi, koi pehle nahi.
 */
@Composable
fun Onboarding(store: Store, onDone: () -> Unit) {
    var multi by remember { mutableStateOf(false) }
    var chosen by remember { mutableStateOf(setOf<String>()) }
    val prev = store.faiths   // pichli baar jo chuna tha

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(tr("Choose your faith", "अपना धर्म चुनें", "Apna dharm chuno"), style = MaterialTheme.typography.headlineMedium)
        Text(
            tr("Your home page will be made for your faith. You can change it later in Setup.",
                "आपका होम पेज आपके धर्म के अनुसार बनेगा। बाद में सेटअप में बदल सकते हैं।",
                "Aapka home page aapke dharm ke hisaab se banega. Baad mein Setup mein badal sakte ho."),
            style = MaterialTheme.typography.bodyMedium
        )
        LanguageChips(store)

        FaithPacks.all.forEach { p ->
            val t = themeForId(p.id)
            val sel = p.id in chosen
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(t.dialFill)
                    .border(if ((multi && sel) || (!multi && p.id in prev)) 3.dp else 1.dp, t.accent, RoundedCornerShape(18.dp))
                    .clickable {
                        if (multi) chosen = if (sel) chosen - p.id else chosen + p.id
                        else { store.faiths = setOf(p.id); onDone() }   // ek tap = us dharm ka home page
                    }
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Symbol(t, false) }
                Column(Modifier.weight(1f)) {
                    if (!multi && p.id in prev) Text(tr("Last chosen", "पिछली बार चुना", "Pichli baar chuna"), color = t.accent, fontSize = 11.sp)
                    Text(p.name(), color = t.cream, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(p.place() + "  \u00B7  " + t.greeting(), color = t.muted, fontSize = 12.sp)
                }
                if (multi) Text(if (sel) "\u2713" else "", color = t.accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (!multi) {
            TextButton(onClick = { multi = true; chosen = prev }) {
                Text(tr("Use for more than one faith?", "एक से ज़्यादा धर्म के लिए इस्तेमाल करना है?", "Ek se zyada dharm ke liye use karna hai?"))
            }
        } else {
            Button(
                enabled = chosen.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
                onClick = { store.faiths = chosen; onDone() }
            ) { Text(tr("Continue", "आगे बढ़ें", "Aage badho")) }
            TextButton(onClick = { multi = false; chosen = emptySet() }) {
                Text(tr("Back: choose one faith", "वापस: एक धर्म चुनें", "Wapas: ek dharm chuno"))
            }
        }
    }
}
