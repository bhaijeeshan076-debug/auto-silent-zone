package com.autosilentzone

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Hindu, Sikh, Christian, Buddhist, Jain, Jewish: unke apne rozana/haftawari waqt, tithi/chand ke din aur reminder. */
class FaithActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        setContent { MaterialTheme { Screen() } }
    }

    private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, hh:mm a", Locale.getDefault()).format(Date(ms))
    private fun dateFmt(ms: Long) = SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(Date(ms))

    private fun pickTime(s: Store, item: TimingItem, done: () -> Unit) {
        val c = Calendar.getInstance().apply { timeInMillis = item.time }
        TimePickerDialog(this@FaithActivity, { _, h, m ->
            s.setTimeMin(item.key, h * 60 + m)
            PrayerReminders.scheduleAll(this@FaithActivity)
            done()
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
    }

    @Composable
    fun Screen() {
        val s = remember { Store(this) }
        var loc by remember { mutableStateOf(if (s.hasLocation) s.lat to s.lng else null) }
        var on by remember { mutableStateOf(s.prayerOn) }
        var lead by remember { mutableStateOf(s.prayerLead) }
        var tick by remember { mutableStateOf(0) }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        val packs = remember { FaithPacks.selected(s).filter { it.id != "islam" && it.id != "custom" } }

        LaunchedEffect(Unit) {
            fetchLocation(this@FaithActivity) { la, lo ->
                loc = la to lo
                PrayerReminders.scheduleAll(this@FaithActivity)
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("Timings", "समय", "Waqt"), style = MaterialTheme.typography.headlineSmall)
            val here = loc
            if (here == null) {
                Text(tr("Location not found. Allow location in Setup, turn on GPS and reopen.",
                    "लोकेशन नहीं मिली। सेटअप में अनुमति दें, GPS चालू करें और फिर खोलें।",
                    "Location nahi mili. Setup mein permission do, GPS on karo aur dobara kholo."))
            } else {
                packs.forEach { pack ->
                    Text(pack.name(), style = MaterialTheme.typography.titleLarge)
                    val items = remember(tick, here, pack.id) { FaithTimings.upcoming(s, pack.id, here.first, here.second) }
                    items.forEach { item ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.label)
                                Text(fmt(item.time), style = MaterialTheme.typography.bodySmall)
                            }
                            if (item.fixed) TextButton(onClick = { pickTime(s, item) { tick++ } }) { Text(tr("Change", "बदलें", "Badlo")) }
                            Switch(
                                checked = item.key in on,
                                onCheckedChange = { v ->
                                    on = if (v) on + item.key else on - item.key
                                    s.prayerOn = on
                                    if (v && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    PrayerReminders.scheduleAll(this@FaithActivity)
                                }
                            )
                        }
                    }
                    Extra(pack.id, here)
                    HorizontalDivider()
                }

                Text(tr("Remind me before", "कितना पहले याद दिलाएँ", "Reminder kitna pehle"), style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to tr("On time", "समय पर", "Waqt pe"), 5 to tr("5 min", "5 मिनट", "5 min"), 10 to tr("10 min", "10 मिनट", "10 min")).forEach { (m, l) ->
                        FilterChip(selected = lead == m, onClick = { lead = m; s.prayerLead = m; PrayerReminders.scheduleAll(this@FaithActivity) }, label = { Text(l) })
                    }
                }
                Text(
                    tr("Sunrise/sunset times are calculated for your location. Traditions differ, so check with your temple/church/gurudwara/vihara/synagogue.",
                        "सूर्योदय/सूर्यास्त का समय आपकी लोकेशन से निकाला गया है। परंपराएँ अलग हो सकती हैं, अपने पूजास्थल से मिलान कर लें।",
                        "Suryoday/suryast ka waqt aapki location se nikala gaya hai. Parampara alag ho sakti hai, apne pooja sthal se milaan kar lena."),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }

    @Composable
    private fun Extra(id: String, loc: Pair<Double, Double>) {
        val now = remember { System.currentTimeMillis() }
        if (id == "hindu") {
            val sunrise = remember(loc) { PrayerTimes.sunEvent(Calendar.getInstance(), loc.first, loc.second, 0.833, true).let { if (it > 0) it else now } }
            val full = remember { Astro.nextPhase(now, 180.0) }
            val new = remember { Astro.nextPhase(now, 0.0) }
            Text(tr("Today's tithi (approx.): ", "आज की तिथि (लगभग): ", "Aaj ki tithi (lagbhag): ") + Astro.tithiText(Astro.tithi(sunrise)))
            Text(tr("Next Purnima: ", "अगली पूर्णिमा: ", "Agli Purnima: ") + dateFmt(full))
            Text(tr("Next Amavasya: ", "अगली अमावस्या: ", "Agli Amavasya: ") + dateFmt(new))
        }
        if (id == "buddhist") {
            val full = remember { Astro.nextPhase(now, 180.0) }
            val new = remember { Astro.nextPhase(now, 0.0) }
            Text(tr("Next Poya / Uposatha (full moon): ", "अगला पोया / उपोसथ (पूर्णिमा): ", "Agla Poya / Uposatha (purnima): ") + dateFmt(full))
            Text(tr("Next Uposatha (new moon): ", "अगला उपोसथ (अमावस्या): ", "Agla Uposatha (amavasya): ") + dateFmt(new))
        }
    }
}
