package com.autosilentzone

import java.util.Calendar

/** OpenStreetMap ke opening_hours tag ka saral reader (jaise "Mo-Su 05:00-21:00; Fr 12:00-14:00"). */
object OpeningHours {
    private val days = listOf("Mo", "Tu", "We", "Th", "Fr", "Sa", "Su")
    private val ruleRe = Regex(
        "^([A-Za-z,\\- ]*?)\\s*((?:\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}(?:\\s*,\\s*)?)+|off|closed)$",
        RegexOption.IGNORE_CASE
    )
    private val rangeRe = Regex("(\\d{1,2}):(\\d{2})\\s*-\\s*(\\d{1,2}):(\\d{2})")

    /** true = khula, false = band, null = pata nahi (tag nahi hai ya samajh nahi aaya) */
    fun isOpen(spec: String?, now: Calendar): Boolean? {
        if (spec.isNullOrBlank()) return null
        return try { eval(spec.trim(), now) } catch (_: Exception) { null }
    }

    private fun eval(spec: String, now: Calendar): Boolean? {
        if (spec == "24/7") return true
        val dow = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7   // Mon = 0 ... Sun = 6
        val mins = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        var result: Boolean? = null
        for (raw in spec.split(";")) {
            val r = raw.trim()
            if (r.isEmpty()) continue
            val m = ruleRe.find(r) ?: return null
            val dayPart = m.groupValues[1].trim()
            val timePart = m.groupValues[2].trim().lowercase()
            if (!dayMatches(dayPart, dow)) continue
            result = if (timePart == "off" || timePart == "closed") false else inRanges(timePart, mins)
        }
        return result ?: false
    }

    private fun dayMatches(part: String, dow: Int): Boolean {
        if (part.isEmpty()) return true
        return part.split(",").any { tok0 ->
            val tok = tok0.trim()
            if (tok.contains("-")) {
                val (a, b) = tok.split("-").map { days.indexOf(it.trim()) }
                if (a < 0 || b < 0) throw IllegalArgumentException()
                if (a <= b) dow in a..b else dow >= a || dow <= b
            } else {
                val i = days.indexOf(tok)
                if (i < 0) throw IllegalArgumentException()
                dow == i
            }
        }
    }

    private fun inRanges(t: String, mins: Int): Boolean = rangeRe.findAll(t).any {
        val s = it.groupValues[1].toInt() * 60 + it.groupValues[2].toInt()
        val e = it.groupValues[3].toInt() * 60 + it.groupValues[4].toInt()
        if (e > s) mins in s until e else mins >= s || mins < e
    }
}
