package com.autosilentzone

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Aapke chune hue dharmon ke agle 12 mahine ke tyohaar. */
class FestivalsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        val s = remember { Store(this) }
        val today = remember { LocalDate.now() }
        val list = remember { try { Festivals.upcoming(s, today) } catch (_: Exception) { emptyList() } }
        val f = remember { DateTimeFormatter.ofPattern("EEE, d MMM yyyy", Locale.getDefault()) }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tr("Festivals & events", "त्योहार और कार्यक्रम", "Tyohaar aur events"), style = MaterialTheme.typography.headlineSmall)
            Text(
                tr("Next 12 months for your chosen faiths. Dates can differ by 1 day with local panchang or moon sighting.",
                    "आपके चुने धर्मों के अगले 12 महीने। स्थानीय पंचांग या चाँद दिखने से तारीख़ 1 दिन अलग हो सकती है।",
                    "Aapke chune dharmon ke agle 12 mahine. Local panchang ya chand dikhne se tareekh 1 din alag ho sakti hai."),
                style = MaterialTheme.typography.bodySmall
            )
            if (list.isEmpty()) Text(tr("Nothing to show.", "दिखाने के लिए कुछ नहीं।", "Dikhane ke liye kuch nahi."))
            list.forEach { fest ->
                val days = ChronoUnit.DAYS.between(today, fest.date)
                val pack = FaithPacks.all.firstOrNull { it.id == fest.faith }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(fest.name, style = MaterialTheme.typography.titleMedium)
                        Text(fest.date.format(f) + (pack?.let { "  \u00B7  " + it.name() } ?: ""), style = MaterialTheme.typography.bodySmall)
                        Text(
                            when {
                                days == 0L -> tr("Today", "आज", "Aaj")
                                days == 1L -> tr("Tomorrow", "कल", "Kal")
                                else -> tr("In $days days", "$days दिन में", "$days din mein")
                            },
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
            Text(
                tr("Hindu, Sikh, Jain and Buddhist festival dates are listed up to 2027; later dates need an app update.",
                    "हिंदू, सिख, जैन और बौद्ध त्योहारों की तारीख़ें 2027 तक हैं; उसके बाद के लिए ऐप अपडेट चाहिए।",
                    "Hindu, Sikh, Jain, Buddhist tyohaar ki tareekhein 2027 tak hain; uske baad ke liye app update chahiye."),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
