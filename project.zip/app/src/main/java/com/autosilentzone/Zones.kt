package com.autosilentzone

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/** Har zone ke liye: radius (50/100/200/500 m), rule (Silent/Vibrate/DND), respect mode. */
@Composable
fun ZoneCard(z: Zone, onChange: (Zone) -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        var renaming by remember { mutableStateOf(false) }
        var newName by remember(z.id) { mutableStateOf(z.name) }
        if (renaming) {
            AlertDialog(
                onDismissRequest = { renaming = false },
                title = { Text(tr("Rename zone", "ज़ोन का नाम बदलें", "Zone ka naam badlo")) },
                text = { OutlinedTextField(newName, { newName = it }, singleLine = true) },
                confirmButton = {
                    TextButton(enabled = newName.isNotBlank(), onClick = { onChange(z.copy(name = newName.trim())); renaming = false }) { Text("OK") }
                },
                dismissButton = { TextButton(onClick = { renaming = false }) { Text(tr("Cancel", "रद्द करें", "Cancel")) } }
            )
        }
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(z.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Row {
                    TextButton(onClick = { renaming = true }) { Text(tr("Rename", "नाम बदलें", "Naam badlo")) }
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "${z.name}: https://maps.google.com/?q=${z.lat},${z.lng}")
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }) { Text("Share") }
                    TextButton(onClick = onDelete) { Text(tr("Remove","हटाएँ","Hatao")) }
                }
            }
            Text(tr("Radius","दायरा","Radius"), style = MaterialTheme.typography.labelMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(50, 100, 200, 500).forEach { r ->
                    FilterChip(selected = z.radius.toInt() == r, onClick = { onChange(z.copy(radius = r.toFloat())) }, label = { Text("$r m") })
                }
            }
            Text(tr("On this spot, phone","इस जगह पर फ़ोन","Is jagah par phone"), style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(tr("Silent","साइलेंट","Silent"), tr("Vibrate","वाइब्रेट","Vibrate"), "DND").forEachIndexed { i, label ->
                    FilterChip(selected = z.mode == i, onClick = { onChange(z.copy(mode = i)) }, label = { Text(label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = z.respect, onCheckedChange = { onChange(z.copy(respect = it)) })
                Text(tr("Respect mode (media volume off too)","रिस्पेक्ट मोड (मीडिया वॉल्यूम भी बंद)","Respect mode (media volume bhi band)"))
            }
        }
    }
}

/** Google Maps mein turn-by-turn rasta. mode: w = paidal, d = gaadi. */
fun openNavigation(ctx: Context, lat: Double, lng: Double, mode: String = "w") {
    val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lng&mode=$mode"))
    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=${if (mode == "w") "walking" else "driving"}"))
    try { ctx.startActivity(nav) } catch (_: Exception) { ctx.startActivity(web) }
}
