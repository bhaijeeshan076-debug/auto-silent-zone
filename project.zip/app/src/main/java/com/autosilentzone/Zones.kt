package com.autosilentzone

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Har zone ke liye: radius (50/100/200/500 m), rule (Silent/Vibrate/DND), respect mode. */
@Composable
fun ZoneCard(z: Zone, onChange: (Zone) -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(z.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onDelete) { Text("Hatao") }
            }
            Text("Radius", style = MaterialTheme.typography.labelMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(50, 100, 200, 500).forEach { r ->
                    FilterChip(selected = z.radius.toInt() == r, onClick = { onChange(z.copy(radius = r.toFloat())) }, label = { Text("$r m") })
                }
            }
            Text("Is jagah par phone", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Silent", "Vibrate", "DND").forEachIndexed { i, label ->
                    FilterChip(selected = z.mode == i, onClick = { onChange(z.copy(mode = i)) }, label = { Text(label) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = z.respect, onCheckedChange = { onChange(z.copy(respect = it)) })
                Text("Respect mode (media volume bhi band)")
            }
        }
    }
}

/** Google Maps mein turn-by-turn rasta. mode: w = paidal, d = gaadi. */
fun openNavigation(ctx: Context, lat: Double, lng: Double, mode: String = "w") {
    val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$lat,$lng&mode=$mode"))
    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=${if (mode == "w") "walking" else "driving"}"))
    try { ctx.startActivity(nav) } catch (_: Exception) { ctx.startActivity(web) }
}
