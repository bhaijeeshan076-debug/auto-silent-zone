package com.autosilentzone

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** App kholne par 3 second ka animation: ring bante hai, ghanti aati hai, silent ki line khinchti hai, naam ubharta hai. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val bg = Color(0xFF0B0B0D)
    val gold = Color(0xFFD4AF37)
    val cream = Color(0xFFF3E2B3)
    val ring = remember { Animatable(0f) }
    val bell = remember { Animatable(0f) }
    val slash = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { ring.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
        launch { delay(500); bell.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        launch { delay(1400); slash.animateTo(1f, tween(600)) }
        delay(3000)
        onDone()
    }

    Column(
        Modifier.fillMaxSize().background(bg).clickable { onDone() },   // tap karo to seedha khul jaye
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Canvas(Modifier.size(220.dp)) {
            val s = size.width / 108f
            // Gold ring: dheere dheere poora banta hai
            drawArc(
                gold, -90f, 360f * ring.value, false,
                topLeft = Offset(24f * s, 24f * s), size = Size(60f * s, 60f * s),
                style = Stroke(2.4f * s, cap = StrokeCap.Round)
            )
            // Ghanti: chhoti se bade hoti hui ubharti hai
            scale(0.6f + 0.4f * bell.value, Offset(54f * s, 54f * s)) {
                val p = Path().apply {
                    moveTo(54f * s, 38f * s)
                    cubicTo(47f * s, 38f * s, 42f * s, 43.5f * s, 42f * s, 50.5f * s)
                    lineTo(42f * s, 57.5f * s)
                    lineTo(38.5f * s, 62.5f * s)
                    lineTo(69.5f * s, 62.5f * s)
                    lineTo(66f * s, 57.5f * s)
                    lineTo(66f * s, 50.5f * s)
                    cubicTo(66f * s, 43.5f * s, 61f * s, 38f * s, 54f * s, 38f * s)
                    close()
                }
                val c = cream.copy(alpha = bell.value)
                drawPath(p, c)
                drawArc(c, 0f, 180f, true, Offset(50.5f * s, 61.5f * s), Size(7f * s, 7f * s))
                drawCircle(c, 2f * s, Offset(54f * s, 35.5f * s))
            }
            // Silent ki tirchi line: upar-left se neeche-right tak khinchti hai
            if (slash.value > 0f) {
                val end = Offset((39f + 30f * slash.value) * s, (39f + 30f * slash.value) * s)
                drawLine(bg, Offset(39f * s, 39f * s), end, 6.5f * s, StrokeCap.Round)
                drawLine(gold, Offset(39f * s, 39f * s), end, 2.8f * s, StrokeCap.Round)
            }
        }
    }
}
