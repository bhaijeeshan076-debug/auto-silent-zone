package com.autosilentzone

import android.content.Context
import android.content.Intent
import java.util.Calendar
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.location.Location
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class Place(val name: String, val religion: String, val lat: Double, val lng: Double, val meters: Int, val open: Boolean? = null)

/** Paas ki puja/ibadat ki jagah dhundo (OpenStreetMap Overpass, free, no API key) + rasta dikhao (Google Maps ya koi bhi maps app). */
object PlaceSearch {
    private val servers = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://lz4.overpass-api.de/api/interpreter",
        "https://overpass.openstreetmap.ru/api/interpreter"
    )

    private fun key(lat: Double, lng: Double, religion: String?) = "n_${"%.3f".format(lat)}_${"%.3f".format(lng)}_${religion ?: "all"}"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("asz_cache", Context.MODE_PRIVATE)

    /** Pichli baar ki list turant dikhane ke liye (internet ka intezaar nahi). */
    fun cached(ctx: Context, lat: Double, lng: Double, religion: String?): List<Place>? =
        prefs(ctx).getString(key(lat, lng, religion), null)?.let {
            try { parseAny(it, lat, lng, religion) } catch (_: Exception) { null }
        }

    /** Teeno server ek saath puchte hain, jo pehle jawab de wahi le lete hain. */
    fun search(ctx: Context, lat: Double, lng: Double, radiusM: Int = 3000, religion: String? = null): List<Place> {
        val rel = when {
            religion == null -> ""
            religion.contains("|") -> "[\"religion\"~\"^($religion)$\"]"
            else -> "[\"religion\"=\"$religion\"]"
        }
        val q = "[out:json][timeout:10];(node[\"amenity\"=\"place_of_worship\"]$rel(around:$radiusM,$lat,$lng);way[\"amenity\"=\"place_of_worship\"]$rel(around:$radiusM,$lat,$lng););out center 30;"
        val enc = URLEncoder.encode(q, "UTF-8")
        val pool = Executors.newFixedThreadPool(servers.size + 1)
        try {
            // Overpass ke 4 server + (2.5 sec baad) Nominatim ka bachav-rasta, jo pehle jawab de wahi
            val tasks = servers.map { s -> Callable<String> { fetch(s, enc) } } + Callable<String> { nominatim(lat, lng, radiusM) }
            val body = pool.invokeAny(tasks, 13, TimeUnit.SECONDS)
            prefs(ctx).edit().putString(key(lat, lng, religion), body).apply()
            return parseAny(body, lat, lng, religion)
        } catch (e: ExecutionException) {
            throw (e.cause as? Exception) ?: e
        } finally {
            pool.shutdownNow()
        }
    }

    private fun fetch(server: String, enc: String): String {
        val c = URL("$server?data=$enc").openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "AutoSilentZone/0.1 (Android app)")
        c.connectTimeout = 5000; c.readTimeout = 12000
        if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().readText()
    }

    private fun nominatim(lat: Double, lng: Double, radiusM: Int): String {
        Thread.sleep(2500)   // pehle Overpass ko mauka do
        val d = radiusM / 111000.0
        val dl = d / Math.cos(Math.toRadians(lat))
        val vb = "${lng - dl},${lat + d},${lng + dl},${lat - d}"
        val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&q=" + URLEncoder.encode("place of worship", "UTF-8") +
            "&viewbox=" + vb + "&bounded=1&limit=40&extratags=1"
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "AutoSilentZone/0.1 (Android app)")
        c.connectTimeout = 5000; c.readTimeout = 9000
        if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
        return "N:" + c.inputStream.bufferedReader().readText()
    }

    private fun parseAny(body: String, lat: Double, lng: Double, religion: String?): List<Place> =
        if (body.startsWith("N:")) parseNominatim(body.substring(2), lat, lng, religion) else parse(body, lat, lng)

    private fun parseNominatim(body: String, lat: Double, lng: Double, religion: String?): List<Place> {
        val arr = JSONArray(body)
        val wanted = religion?.split("|")?.toSet()
        val out = mutableListOf<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ex = o.optJSONObject("extratags")
            val rel = ex?.optString("religion", "") ?: ""
            if (wanted != null && rel !in wanted) continue
            val la = o.optString("lat", "").toDoubleOrNull() ?: continue
            val lo = o.optString("lon", "").toDoubleOrNull() ?: continue
            val r = FloatArray(1); Location.distanceBetween(lat, lng, la, lo, r)
            val nm = o.optString("name", "").ifEmpty { o.optString("display_name", "").substringBefore(",") }
                .ifEmpty { tr("Name not listed", "नाम नहीं मिला", "Naam nahi mila") }
            out += Place(nm, rel, la, lo, r[0].toInt(),
                OpeningHours.isOpen(ex?.optString("opening_hours", "")?.ifEmpty { null }, Calendar.getInstance()))
        }
        return out.sortedBy { it.meters }
    }

    private fun parse(body: String, lat: Double, lng: Double): List<Place> {
        val els = JSONObject(body).getJSONArray("elements")
        val out = mutableListOf<Place>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: continue
            val la = e.optDouble("lat", e.optJSONObject("center")?.optDouble("lat") ?: Double.NaN)
            val lo = e.optDouble("lon", e.optJSONObject("center")?.optDouble("lon") ?: Double.NaN)
            if (la.isNaN() || lo.isNaN()) continue
            val r = FloatArray(1); Location.distanceBetween(lat, lng, la, lo, r)
            out += Place(t.optString("name", tr("Name not listed","नाम नहीं मिला","Naam nahi mila")), t.optString("religion", ""), la, lo, r[0].toInt(),
                OpeningHours.isOpen(t.optString("opening_hours", "").ifEmpty { null }, Calendar.getInstance()))
        }
        return out.sortedBy { it.meters }
    }
}

class NearbyActivity : ComponentActivity() {
    @Volatile private var gen = 0

    /** Sirf chune hue dharm ke chips. Ek se zyada chune ho to pehle "Sabhi (mere dharm)". */
    private val faiths: List<Pair<String, String?>>
        get() {
            val packs = FaithPacks.selected(Store(this))
            val tagged = packs.filter { it.osmTag != null }
            val hasCustom = packs.any { it.osmTag == null }
            if (tagged.isEmpty() || hasCustom) return listOf(tr("All", "सभी", "Sabhi") to (null as String?)) + tagged.map { it.name() to it.osmTag }
            if (tagged.size == 1) return listOf(tagged[0].name() to tagged[0].osmTag)
            return listOf(tr("All my faiths", "मेरे सभी धर्म", "Mere sabhi dharm") to tagged.joinToString("|") { it.osmTag!! }) +
                tagged.map { it.name() to it.osmTag }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        var faith by remember { mutableStateOf(faiths.first().second) }
        var places by remember { mutableStateOf<List<Place>>(emptyList()) }
        var status by remember { mutableStateOf(tr("Searching...","खोज रहे हैं...","Dhundh rahe hain...")) }
        var here by remember { mutableStateOf<Pair<Double, Double>?>(null) }
        var searching by remember { mutableStateOf(true) }
        var retry by remember { mutableStateOf(0) }

        LaunchedEffect(Unit) {
            status = tr("Tracking your location (4-5 sec)...", "लोकेशन ट्रैक हो रही है (4-5 सेकंड)...", "Location track ho rahi hai (4-5 sec)...")
            val st = Store(this@NearbyActivity)
            freshLocation(this@NearbyActivity, 5000L) { loc ->
                if (loc != null) here = loc
                else if (st.hasLocation) here = st.lat to st.lng
                else { status = tr("Location not found. Turn on GPS.", "लोकेशन नहीं मिली। GPS चालू करें।", "Location nahi mili. GPS on karo."); searching = false }
            }
        }
        LaunchedEffect(here, faith, retry) {
            val h = here ?: return@LaunchedEffect
            val cached = PlaceSearch.cached(this@NearbyActivity, h.first, h.second, faith)
            if (cached != null) { places = cached; status = tr("Showing saved list, refreshing...","पुरानी सूची दिख रही है, नई ला रहे हैं...","Purani list dikh rahi hai, naya la rahe hain...") }
            else status = tr("Searching...","खोज रहे हैं...","Dhundh rahe hain...")
            val myGen = ++gen
            searching = true
            Thread {
                var best: List<Place> = cached ?: emptyList()
                var lastErr: Throwable? = null
                for (radius in listOf(1000, 3000, 6000)) {   // pehle paas ka (tez), kam mile to door tak
                    try {
                        val r = PlaceSearch.search(this@NearbyActivity, h.first, h.second, radius, faith)
                        best = r
                        runOnUiThread {
                            if (myGen == gen) {
                                places = r
                                status = if (r.size >= 5 || radius == 6000) "" else tr("Looking wider...", "और दूर तक खोज रहे हैं...", "Aur door tak dhundh rahe hain...")
                            }
                        }
                        if (r.size >= 5) break
                    } catch (e: Throwable) { lastErr = e; break }
                }
                runOnUiThread {
                    if (myGen == gen) {
                        if (best.isEmpty()) {
                            status = if (lastErr != null)
                                tr("Search failed (free map servers are slow). Try again.", "खोज नहीं हो पाई (फ्री मैप सर्वर धीमे हैं)। फिर कोशिश करें।", "Search nahi ho paya (free map server dheere hain). Dobara try karo.") + " [" + lastErr!!.javaClass.simpleName + "]"
                            else tr("Nothing found within 6 km", "6 किमी में कुछ नहीं मिला", "6 km mein kuch nahi mila")
                        } else status = ""
                        searching = false
                    }
                }
            }.start()
        }

        Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(nearbyLabel(Store(this@NearbyActivity)), style = MaterialTheme.typography.headlineSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                faiths.forEach { (label, tag) ->
                    FilterChip(selected = faith == tag, onClick = { faith = tag }, label = { Text(label) })
                }
            }
            if (status.isNotEmpty()) Text(status)
            if (!searching && places.isEmpty()) TextButton(onClick = { retry++ }) { Text(tr("Retry", "फिर कोशिश करें", "Dobara try karo")) }
            here?.let { h ->
                TextButton(onClick = {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.openstreetmap.org/note/new#map=19/${h.first}/${h.second}")))
                }) { Text(tr("Place missing? Add it on OpenStreetMap","जगह नहीं मिली? OpenStreetMap पर जोड़ें","Jagah nahi mili? OpenStreetMap pe jodo")) }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(places) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text((if (p.meters < 1000) "${p.meters} m" else "%.1f km".format(p.meters / 1000f)) + " " + tr("away", "दूर", "door"))
                            Text(
                                when (p.open) {
                                    true -> tr("Open now", "अभी खुला है", "Abhi khula hai")
                                    false -> tr("Closed now", "अभी बंद है", "Abhi band hai")
                                    null -> tr("Timing not listed", "समय पता नहीं", "Timing pata nahi")
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { navigate(p, "w") }) { Text(tr("Directions","रास्ता दिखाएँ","Raasta dikhao")) }
                                OutlinedButton(onClick = { addZone(p) }) { Text(tr("Make zone","ज़ोन बनाएँ","Zone banao")) }
                                OutlinedButton(onClick = { addFavourite(p) }) { Text(tr("Favourite","पसंदीदा","Favourite")) }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Google Maps mein turn-by-turn navigation (w = paidal, d = gaadi). Maps app na ho to browser mein khulega. */
    private fun navigate(p: Place, mode: String) {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${p.lat},${p.lng}&mode=$mode"))
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}&travelmode=${if (mode == "w") "walking" else "driving"}"))
        try { startActivity(nav) } catch (_: Exception) { startActivity(web) }
    }

    private fun toast(msg: String) = android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()

    private fun addFavourite(p: Place) {
        val s = Store(this)
        if (s.favPlaces().any { it.lat == p.lat && it.lng == p.lng }) { toast(tr("Already a favourite","पहले से पसंदीदा है","Pehle se favourite hai")); return }
        s.saveFavPlaces(s.favPlaces() + Zone(UUID.randomUUID().toString(), p.name, p.lat, p.lng))
        toast("Favourite mein jod diya: ${p.name}")
    }

    private fun addZone(p: Place) {
        val s = Store(this)
        if (s.zones().any { it.lat == p.lat && it.lng == p.lng }) { toast(tr("This zone already exists","यह ज़ोन पहले से बना है","Ye zone pehle se bana hua hai")); return }
        s.saveZones(s.zones() + Zone(UUID.randomUUID().toString(), p.name, p.lat, p.lng))
        try {
            Geofences.register(this)
            toast("Zone ban gaya: ${p.name}")
        } catch (e: Exception) {
            toast("Zone save hua, par location permission do (${e.message})")
        }
    }
}
