package com.autosilentzone

import android.content.Intent
import android.location.Location
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class Place(val name: String, val religion: String, val lat: Double, val lng: Double, val meters: Int)

/** Paas ki puja/ibadat ki jagah dhundo (OpenStreetMap Overpass, free, no API key) + rasta dikhao (Google Maps ya koi bhi maps app). */
object PlaceSearch {
    fun search(lat: Double, lng: Double, radiusM: Int = 3000, religion: String? = null): List<Place> {
        val rel = if (religion != null) "[\"religion\"=\"$religion\"]" else ""
        val q = "[out:json][timeout:20];nwr[\"amenity\"=\"place_of_worship\"]$rel(around:$radiusM,$lat,$lng);out center 60;"
        val c = URL("https://overpass-api.de/api/interpreter?data=" + URLEncoder.encode(q, "UTF-8")).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 25000
        val els = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("elements")
        val out = mutableListOf<Place>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: continue
            val la = e.optDouble("lat", e.optJSONObject("center")?.optDouble("lat") ?: Double.NaN)
            val lo = e.optDouble("lon", e.optJSONObject("center")?.optDouble("lon") ?: Double.NaN)
            if (la.isNaN() || lo.isNaN()) continue
            val r = FloatArray(1); Location.distanceBetween(lat, lng, la, lo, r)
            out += Place(t.optString("name", "Naam nahi mila"), t.optString("religion", ""), la, lo, r[0].toInt())
        }
        return out.sortedBy { it.meters }
    }
}

class NearbyActivity : ComponentActivity() {
    private val faiths get() = listOf("Sabhi" to (null as String?)) +
        FaithPacks.selected(Store(this)).filter { it.osmTag != null }.map { it.label to it.osmTag }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        var faith by remember { mutableStateOf<String?>(null) }
        var places by remember { mutableStateOf<List<Place>>(emptyList()) }
        var status by remember { mutableStateOf("Dhundh rahe hain...") }
        var here by remember { mutableStateOf<Pair<Double, Double>?>(null) }

        LaunchedEffect(Unit) {
            try {
                LocationServices.getFusedLocationProviderClient(this@NearbyActivity).lastLocation.addOnSuccessListener {
                    if (it != null) here = it.latitude to it.longitude else status = "Location nahi mili. GPS on karo."
                }
            } catch (_: SecurityException) { status = "Location permission do." }
        }
        LaunchedEffect(here, faith) {
            val h = here ?: return@LaunchedEffect
            status = "Dhundh rahe hain..."
            Thread {
                try {
                    val r = PlaceSearch.search(h.first, h.second, religion = faith)
                    runOnUiThread { places = r; status = if (r.isEmpty()) "3 km mein kuch nahi mila" else "" }
                } catch (e: Exception) { runOnUiThread { status = "Internet check karo" } }
            }.start()
        }

        Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Paas ki jagah", style = MaterialTheme.typography.headlineSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                faiths.forEach { (label, tag) ->
                    FilterChip(selected = faith == tag, onClick = { faith = tag }, label = { Text(label) })
                }
            }
            if (status.isNotEmpty()) Text(status)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(places) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text(if (p.meters < 1000) "${p.meters} m door" else "%.1f km door".format(p.meters / 1000f))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { navigate(p, "w") }) { Text("Raasta dikhao") }
                                OutlinedButton(onClick = { addZone(p) }) { Text("Zone banao") }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Google Maps mein turn-by-turn navigation (w = paidal, d = gaadi). Maps app na ho to browser mein khulega. */
    private fun navigate(p: Place, mode: String) {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${p.lat},${p.lng}&mode=$mode"))
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}&travelmode=${if (mode == "w") "walking" else "driving"}"))
        try { startActivity(nav) } catch (_: Exception) { startActivity(web) }
    }

    private fun addZone(p: Place) {
        val s = Store(this)
        s.saveZones(s.zones() + Zone(UUID.randomUUID().toString(), p.name, p.lat, p.lng))
        Geofences.register(this)
    }
}
