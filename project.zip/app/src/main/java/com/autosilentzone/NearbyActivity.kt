package com.autosilentzone

import android.content.Context
import android.content.Intent
import java.util.Calendar
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import android.location.Location
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class Place(val name: String, val religion: String, val lat: Double, val lng: Double, val meters: Int, val open: Boolean? = null)

/** Paas ki puja/ibadat ki jagah dhundo (OpenStreetMap Overpass, free, no API key) + rasta dikhao (Google Maps ya koi bhi maps app). */
object PlaceSearch {
    private val servers = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter"
    )

    private fun key(lat: Double, lng: Double, religion: String?) = "n_${"%.3f".format(lat)}_${"%.3f".format(lng)}_${religion ?: "all"}"
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("asz_cache", Context.MODE_PRIVATE)

    /** Pichli baar ki list turant dikhane ke liye (internet ka intezaar nahi). */
    fun cached(ctx: Context, lat: Double, lng: Double, religion: String?): List<Place>? =
        prefs(ctx).getString(key(lat, lng, religion), null)?.let {
            try { parse(it, lat, lng) } catch (_: Exception) { null }
        }

    /** Teeno server ek saath puchte hain, jo pehle jawab de wahi le lete hain. */
    fun search(ctx: Context, lat: Double, lng: Double, radiusM: Int = 3000, religion: String? = null): List<Place> {
        val rel = if (religion != null) "[\"religion\"=\"$religion\"]" else ""
        val q = "[out:json][timeout:12];nwr[\"amenity\"=\"place_of_worship\"]$rel(around:$radiusM,$lat,$lng);out center 40;"
        val enc = URLEncoder.encode(q, "UTF-8")
        val pool = Executors.newFixedThreadPool(servers.size)
        try {
            val body = pool.invokeAny(servers.map { s -> Callable<String> { fetch(s, enc) } }, 20, TimeUnit.SECONDS)
            prefs(ctx).edit().putString(key(lat, lng, religion), body).apply()
            return parse(body, lat, lng)
        } catch (e: ExecutionException) {
            throw (e.cause as? Exception) ?: e
        } finally {
            pool.shutdownNow()
        }
    }

    private fun fetch(server: String, enc: String): String {
        val c = URL("$server?data=$enc").openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "AutoSilentZone/0.1 (Android app)")
        c.connectTimeout = 6000; c.readTimeout = 15000
        if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().readText()
    }

    private fun parse(body: String, lat: Double, lng: Double): List<Place> {
        val els = JSONObject(body).getJSONArray("elements")
        val out = mutableListOf<Place>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            val t = e.optJSONObject("tags") ?: continue
            val la = e.optDouble("lat", e.optJSONObject("center")?.optDouble("lat") ?: Double.NaN)
            val lo = e.optDouble("lon", e.optJSONObject("center")?.optDouble("lon") ?: Double.NaN)
            if (la.isNaN() || lo.isNaN()) continue
            val r = FloatArray(1); Location.distanceBetween(lat, lng, la, lo, r)
            out += Place(t.optString("name", tr("Name not listed","नाम नहीं मिला","Naam nahi mila")), t.optString("religion", ""), la, lo, r[0].toInt(),
                OpeningHours.isOpen(t.optString("opening_hours", "").ifEmpty { null }, Calendar.getInstance()))
        }
        return out.sortedBy { it.meters }
    }
}

class NearbyActivity : ComponentActivity() {
    @Volatile private var gen = 0

    private val faiths get() = listOf(tr("All","सभी","Sabhi") to (null as String?)) +
        FaithPacks.selected(Store(this)).filter { it.osmTag != null }.map { it.name() to it.osmTag }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        var faith by remember { mutableStateOf<String?>(null) }
        var places by remember { mutableStateOf<List<Place>>(emptyList()) }
        var status by remember { mutableStateOf(tr("Searching...","खोज रहे हैं...","Dhundh rahe hain...")) }
        var here by remember { mutableStateOf<Pair<Double, Double>?>(null) }

        LaunchedEffect(Unit) {
            try {
                LocationServices.getFusedLocationProviderClient(this@NearbyActivity).lastLocation.addOnSuccessListener {
                    if (it != null) here = it.latitude to it.longitude else status = tr("Location not found. Turn on GPS.","लोकेशन नहीं मिली। GPS चालू करें।","Location nahi mili. GPS on karo.")
                }
            } catch (_: SecurityException) { status = tr("Please grant location permission.","लोकेशन की अनुमति दें।","Location permission do.") }
        }
        LaunchedEffect(here, faith) {
            val h = here ?: return@LaunchedEffect
            val cached = PlaceSearch.cached(this@NearbyActivity, h.first, h.second, faith)
            if (cached != null) { places = cached; status = tr("Showing saved list, refreshing...","पुरानी सूची दिख रही है, नई ला रहे हैं...","Purani list dikh rahi hai, naya la rahe hain...") }
            else status = tr("Searching...","खोज रहे हैं...","Dhundh rahe hain...")
            val myGen = ++gen
            Thread {
                try {
                    val r = PlaceSearch.search(this@NearbyActivity, h.first, h.second, religion = faith)
                    runOnUiThread { if (myGen != gen) return@runOnUiThread; places = r; status = if (r.isEmpty()) tr("Nothing found within 3 km","3 किमी में कुछ नहीं मिला","3 km mein kuch nahi mila") else "" }
                } catch (e: Exception) { runOnUiThread { if (myGen != gen) return@runOnUiThread; status = "Search nahi ho paya (${e.javaClass.simpleName}: ${e.message}). Dobara try karo." } }
            }.start()
        }

        Column(Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("Nearby places","पास की जगह","Paas ki jagah"), style = MaterialTheme.typography.headlineSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                faiths.forEach { (label, tag) ->
                    FilterChip(selected = faith == tag, onClick = { faith = tag }, label = { Text(label) })
                }
            }
            if (status.isNotEmpty()) Text(status)
            here?.let { h ->
                TextButton(onClick = {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.openstreetmap.org/note/new#map=19/${h.first}/${h.second}")))
                }) { Text(tr("Place missing? Add it on OpenStreetMap","जगह नहीं मिली? OpenStreetMap पर जोड़ें","Jagah nahi mili? OpenStreetMap pe jodo")) }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(places) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text((if (p.meters < 1000) "${p.meters} m" else "%.1f km".format(p.meters / 1000f)) + " " + tr("away", "दूर", "door"))
                            Text(
                                when (p.open) {
                                    true -> tr("Open now", "अभी खुला है", "Abhi khula hai")
                                    false -> tr("Closed now", "अभी बंद है", "Abhi band hai")
                                    null -> tr("Timing not listed", "समय पता नहीं", "Timing pata nahi")
                                },
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { navigate(p, "w") }) { Text(tr("Directions","रास्ता दिखाएँ","Raasta dikhao")) }
                                OutlinedButton(onClick = { addZone(p) }) { Text(tr("Make zone","ज़ोन बनाएँ","Zone banao")) }
                                OutlinedButton(onClick = { addFavourite(p) }) { Text(tr("Favourite","पसंदीदा","Favourite")) }
                            }
                        }
                    }
                }
            }
        }
    }

    /** Google Maps mein turn-by-turn navigation (w = paidal, d = gaadi). Maps app na ho to browser mein khulega. */
    private fun navigate(p: Place, mode: String) {
        val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${p.lat},${p.lng}&mode=$mode"))
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}&travelmode=${if (mode == "w") "walking" else "driving"}"))
        try { startActivity(nav) } catch (_: Exception) { startActivity(web) }
    }

    private fun toast(msg: String) = android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()

    private fun addFavourite(p: Place) {
        val s = Store(this)
        if (s.favPlaces().any { it.lat == p.lat && it.lng == p.lng }) { toast(tr("Already a favourite","पहले से पसंदीदा है","Pehle se favourite hai")); return }
        s.saveFavPlaces(s.favPlaces() + Zone(UUID.randomUUID().toString(), p.name, p.lat, p.lng))
        toast("Favourite mein jod diya: ${p.name}")
    }

    private fun addZone(p: Place) {
        val s = Store(this)
        if (s.zones().any { it.lat == p.lat && it.lng == p.lng }) { toast(tr("This zone already exists","यह ज़ोन पहले से बना है","Ye zone pehle se bana hua hai")); return }
        s.saveZones(s.zones() + Zone(UUID.randomUUID().toString(), p.name, p.lat, p.lng))
        try {
            Geofences.register(this)
            toast("Zone ban gaya: ${p.name}")
        } catch (e: Exception) {
            toast("Zone save hua, par location permission do (${e.message})")
        }
    }
}
