package com.autosilentzone

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager

object SilentController {
    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private fun am(c: Context) = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun canControl(ctx: Context) = nm(ctx).isNotificationPolicyAccessGranted

    /** mode 0 = Silent, 1 = Vibrate, 2 = DND */
    private fun applyMode(ctx: Context, mode: Int) {
        try {
            when (mode) {
                1 -> am(ctx).ringerMode = AudioManager.RINGER_MODE_VIBRATE
                2 -> nm(ctx).setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
                else -> am(ctx).ringerMode = AudioManager.RINGER_MODE_SILENT
            }
        } catch (_: SecurityException) {}
    }

    fun enterZone(ctx: Context, z: Zone) {
        val s = Store(ctx)
        if (s.activeZone == null) {   // purani state sirf pehli baar yaad rakho
            s.savedRinger = am(ctx).ringerMode
            s.savedFilter = nm(ctx).currentInterruptionFilter
            s.savedMusic = am(ctx).getStreamVolume(AudioManager.STREAM_MUSIC)
        }
        s.activeZone = z.name
        s.activeMode = z.mode
        s.activeRespect = z.respect
        s.resetCounters()
        if (!canControl(ctx)) return
        applyMode(ctx, z.mode)
        if (z.respect) try { am(ctx).setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0) } catch (_: SecurityException) {}
    }

    fun exitZone(ctx: Context) {
        val s = Store(ctx)
        if (s.activeZone != null && canControl(ctx)) {
            try {
                if (s.savedFilter != -1) nm(ctx).setInterruptionFilter(s.savedFilter)
                if (s.savedRinger != -1) am(ctx).ringerMode = s.savedRinger
                if (s.activeRespect && s.savedMusic != -1) am(ctx).setStreamVolume(AudioManager.STREAM_MUSIC, s.savedMusic, 0)
            } catch (_: SecurityException) {}
        }
        s.activeZone = null
        s.savedRinger = -1; s.savedFilter = -1; s.savedMusic = -1
        s.resetCounters()
    }

    /** Zaroori call: DND/silent hatao taaki phone ring ho. */
    fun ringNow(ctx: Context) {
        if (!canControl(ctx)) return
        try {
            nm(ctx).setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            am(ctx).ringerMode = AudioManager.RINGER_MODE_NORMAL
        } catch (_: SecurityException) {}
    }

    fun backToSilent(ctx: Context) {
        val s = Store(ctx)
        if (s.activeZone == null || !canControl(ctx)) return
        applyMode(ctx, s.activeMode)
    }
}
