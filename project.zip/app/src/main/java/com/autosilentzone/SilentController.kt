package com.autosilentzone

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager

object SilentController {
    fun canControl(ctx: Context) =
        (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted

    fun enterZone(ctx: Context, zoneName: String) {
        val s = Store(ctx)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (s.activeZone == null) s.savedRinger = am.ringerMode   // purana mode yaad rakho
        s.activeZone = zoneName
        s.resetCounters()
        if (canControl(ctx)) am.ringerMode = AudioManager.RINGER_MODE_SILENT
    }

    fun exitZone(ctx: Context) {
        val s = Store(ctx)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (s.activeZone != null && s.savedRinger != -1 && canControl(ctx)) am.ringerMode = s.savedRinger
        s.activeZone = null
        s.resetCounters()
    }

    fun ringNow(ctx: Context) {
        if (!canControl(ctx)) return
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.ringerMode = AudioManager.RINGER_MODE_NORMAL
    }

    fun backToSilent(ctx: Context) {
        if (Store(ctx).activeZone == null || !canControl(ctx)) return
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).ringerMode = AudioManager.RINGER_MODE_SILENT
    }
}
