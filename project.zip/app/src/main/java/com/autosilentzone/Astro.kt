package com.autosilentzone

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Chand, sooraj aur Qibla ka hisaab (bina internet). Chand ka hisaab lagbhag 0.3 degree tak sahi. */
object Astro {
    private fun rad(d: Double) = Math.toRadians(d)
    private fun norm(d: Double) = ((d % 360.0) + 360.0) % 360.0
    private fun centuries(ms: Long) = (ms / 86400000.0 + 2440587.5 - 2451545.0) / 36525.0

    fun sunLon(ms: Long): Double {
        val t = centuries(ms)
        val l0 = 280.46646 + 36000.76983 * t
        val m = rad(357.52911 + 35999.05029 * t)
        return norm(l0 + 1.914602 * sin(m) + 0.019993 * sin(2 * m))
    }

    fun moonLon(ms: Long): Double {
        val t = centuries(ms)
        val lp = 218.3164477 + 481267.88123421 * t
        val d = rad(297.8501921 + 445267.1114034 * t)
        val m = rad(357.5291092 + 35999.0502909 * t)
        val mp = rad(134.9633964 + 477198.8675055 * t)
        val f = rad(93.2720950 + 483202.0175233 * t)
        val l = lp + 6.288774 * sin(mp) + 1.274027 * sin(2 * d - mp) + 0.658314 * sin(2 * d) +
            0.213618 * sin(2 * mp) - 0.185116 * sin(m) - 0.114332 * sin(2 * f) +
            0.058793 * sin(2 * d - 2 * mp) + 0.057066 * sin(2 * d - m - mp) +
            0.053322 * sin(2 * d + mp) + 0.045758 * sin(2 * d - m)
        return norm(l)
    }

    fun elongation(ms: Long) = norm(moonLon(ms) - sunLon(ms))

    /** Tithi 1..30 (1-15 Shukla, 16-30 Krishna) */
    fun tithi(ms: Long): Int = (elongation(ms) / 12.0).toInt().coerceIn(0, 29) + 1

    private val tithiNames = listOf(
        "Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami", "Ashtami",
        "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi"
    )

    fun tithiText(n: Int): String {
        val idx = (n - 1) % 15
        val paksha = if (n <= 15) "Shukla" else "Krishna"
        val name = if (idx == 14) (if (n <= 15) "Purnima" else "Amavasya") else tithiNames[idx]
        return "$paksha $name"
    }

    /** target 0.0 = new moon (amavasya), 180.0 = full moon (purnima). Agla aisa moment (millis). */
    fun nextPhase(from: Long, target: Double): Long {
        fun diff(x: Long) = ((elongation(x) - target + 540.0) % 360.0) - 180.0
        var a = from
        var da = diff(a)
        var b = a
        val step = 3 * 3600_000L
        for (i in 0 until 300) {
            b = a + step
            val db = diff(b)
            if (da < 0 && db >= 0) break
            a = b; da = db
        }
        var lo = a
        var hi = b
        repeat(30) {
            val mid = (lo + hi) / 2
            if (diff(mid) < 0) lo = mid else hi = mid
        }
        return (lo + hi) / 2
    }

    /** Qibla ki disha (North se degree mein). */
    fun qiblaBearing(lat: Double, lng: Double): Double {
        val kLat = rad(21.4225)
        val kLng = rad(39.8262)
        val phi = rad(lat)
        val dl = kLng - rad(lng)
        val y = sin(dl) * cos(kLat)
        val x = cos(phi) * sin(kLat) - sin(phi) * cos(kLat) * cos(dl)
        return norm(Math.toDegrees(atan2(y, x)))
    }
}

/** Aakhri jaani hui location leke Store mein rakhta hai. */
@SuppressLint("MissingPermission")
fun fetchLocation(ctx: Context, onLoc: (Double, Double) -> Unit) {
    try {
        LocationServices.getFusedLocationProviderClient(ctx).lastLocation.addOnSuccessListener {
            if (it != null) {
                val s = Store(ctx)
                s.lat = it.latitude; s.lng = it.longitude
                onLoc(it.latitude, it.longitude)
            }
        }
    } catch (_: SecurityException) {}
}
