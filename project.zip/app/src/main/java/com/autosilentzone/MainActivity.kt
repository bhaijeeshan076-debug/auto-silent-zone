package com.autosilentzone

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import java.util.UUID

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent {
            MaterialTheme {
                var ready by remember { mutableStateOf(store.faiths.isNotEmpty()) }
                if (ready) Screen(store) else Onboarding(store) { ready = true }
            }
        }
    }

    @Composable
    fun Screen(store: Store) {
        var zones by remember(tick) { mutableStateOf(store.zones()) }
        var name by remember { mutableStateOf("") }
        var threshold by remember { mutableStateOf(store.threshold.toFloat()) }
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Auto Silent Zone", style = MaterialTheme.typography.headlineSmall)
            Text(store.activeZone?.let { "🔕 Silent on hai: $it" } ?: "Abhi koi zone active nahi")

            Button(onClick = { startActivity(Intent(this@MainActivity, NearbyActivity::class.java)) }) { Text("📍 Paas ki masjid/mandir/church dhundo") }

            Text("Aapke pack: " + FaithPacks.selected(store).joinToString { it.label })
            TextButton(onClick = { store.faiths = emptySet(); recreate() }) { Text("Dharm badlo") }

            Text("Setup (ek baar)", style = MaterialTheme.typography.titleMedium)
            Button(onClick = {
                perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
            }) { Text("1. Location permission") }
            Button(onClick = {
                perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
            }) { Text("2. Location: Allow all the time") }
            Button(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) {
                Text("3. Do Not Disturb access")
            }
            Button(onClick = {
                val rm = getSystemService(RoleManager::class.java)
                startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }) { Text("4. Call screening role (repeat-call ke liye)") }

            Text("Repeat call: ${threshold.toInt()} call pe ring (${store.windowMin} min ke andar)")
            Slider(value = threshold, onValueChange = { threshold = it; store.threshold = it.toInt() }, valueRange = 2f..10f, steps = 7)

            Text("Zone add karo (abhi jahan ho wahan)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text("Naam (jaise Jama Masjid)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                try {
                    LocationServices.getFusedLocationProviderClient(this@MainActivity).lastLocation.addOnSuccessListener { loc ->
                        if (loc != null && name.isNotBlank()) {
                            zones = zones + Zone(UUID.randomUUID().toString(), name.trim(), loc.latitude, loc.longitude)
                            store.saveZones(zones); Geofences.register(this@MainActivity); name = ""
                        }
                    }
                } catch (_: SecurityException) {}
            }) { Text("Yahan zone banao") }

            zones.forEach { z ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(z.name, Modifier.weight(1f))
                    TextButton(onClick = {
                        zones = zones - z; store.saveZones(zones); Geofences.register(this@MainActivity)
                    }) { Text("Hatao") }
                }
            }
        }
    }
}
