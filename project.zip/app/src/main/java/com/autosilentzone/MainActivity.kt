package com.autosilentzone

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import java.util.UUID

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() { super.onResume(); tick++ }

    private fun pinSpot(name: String) {
        try {
            LocationServices.getFusedLocationProviderClient(this).lastLocation.addOnSuccessListener { loc ->
                if (loc == null) { toast("Location nahi mili. GPS on karo."); return@addOnSuccessListener }
                val s = Store(this)
                s.saveZones(s.zones() + Zone(UUID.randomUUID().toString(), name.trim(), loc.latitude, loc.longitude))
                try { Geofences.register(this); toast("Zone ban gaya: ${name.trim()}") }
                catch (e: Exception) { toast("Zone save hua, par location permission do") }
                tick++
            }
        } catch (_: SecurityException) { toast("Pehle Setup mein location permission do") }
    }

    private fun toast(msg: String) = android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0B0B0D")
        window.navigationBarColor = android.graphics.Color.parseColor("#0B0B0D")
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        val store = Store(this)
        setContent {
            MaterialTheme {
                var ready by remember { mutableStateOf(store.faiths.isNotEmpty()) }
                if (!ready) Onboarding(store) { ready = true } else {
                    var page by remember { mutableStateOf("home") }
                    BackHandler(page != "home") { page = "home" }
                    if (page == "home") HomeScreen(
                        store, tick,
                        onSetup = { page = "settings" },
                        onNearby = { startActivity(Intent(this@MainActivity, NearbyActivity::class.java)) },
                        onPrayer = { startActivity(Intent(this@MainActivity, PrayerActivity::class.java)) },
                        onPin = { pinSpot(it) }
                    ) else SetupScreen(store)
                }
            }
        }
    }

    @Composable
    fun SetupScreen(store: Store) {
        var zones by remember(tick) { mutableStateOf(store.zones()) }
        var name by remember { mutableStateOf("") }
        var threshold by remember { mutableStateOf(store.threshold.toFloat()) }
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        var favs by remember(tick) { mutableStateOf(store.favNames()) }
        var places by remember(tick) { mutableStateOf(store.favPlaces()) }
        val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = r.data?.data
            if (r.resultCode == RESULT_OK && uri != null) {
                contentResolver.query(
                    uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) { store.addFavourite(c.getString(1) ?: "Contact", c.getString(0) ?: ""); favs = store.favNames() }
                }
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Auto Silent Zone", style = MaterialTheme.typography.headlineSmall)
            Text(store.activeZone?.let { "🔕 Silent on hai: $it" } ?: "Abhi koi zone active nahi")

            Button(onClick = { startActivity(Intent(this@MainActivity, NearbyActivity::class.java)) }) { Text("📍 Paas ki masjid/mandir/church dhundo") }

            Text("Aapke pack: " + FaithPacks.selected(store).joinToString { it.label })
            TextButton(onClick = { store.faiths = emptySet(); recreate() }) { Text("Dharm badlo") }

            Text("Setup (ek baar)", style = MaterialTheme.typography.titleMedium)
            Button(onClick = {
                perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
            }) { Text("1. Location permission") }
            Button(onClick = {
                perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
            }) { Text("2. Location: Allow all the time") }
            Button(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) {
                Text("3. Do Not Disturb access")
            }
            Button(onClick = {
                val rm = getSystemService(RoleManager::class.java)
                startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }) { Text("4. Call screening role (repeat-call ke liye)") }

            Text("Repeat call: ${threshold.toInt()} call pe ring (${store.windowMin} min ke andar)")
            Slider(value = threshold, onValueChange = { threshold = it; store.threshold = it.toInt() }, valueRange = 2f..10f, steps = 7)

            Text("Zone add karo (abhi jahan ho wahan)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text("Naam (jaise Jama Masjid)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                try {
                    LocationServices.getFusedLocationProviderClient(this@MainActivity).lastLocation.addOnSuccessListener { loc ->
                        if (loc != null && name.isNotBlank()) {
                            zones = zones + Zone(UUID.randomUUID().toString(), name.trim(), loc.latitude, loc.longitude)
                            store.saveZones(zones); Geofences.register(this@MainActivity); name = ""
                        }
                    }
                } catch (_: SecurityException) {}
            }) { Text("Yahan zone banao") }

            Text("Meri jagahein: radius aur rule", style = MaterialTheme.typography.titleMedium)
            zones.forEach { z ->
                ZoneCard(
                    z,
                    onChange = { nz ->
                        zones = zones.map { if (it.id == nz.id) nz else it }
                        store.saveZones(zones)
                        try { Geofences.register(this@MainActivity) } catch (_: Exception) {}
                    },
                    onDelete = {
                        zones = zones - z; store.saveZones(zones)
                        try { Geofences.register(this@MainActivity) } catch (_: Exception) {}
                    }
                )
            }

            Text("Zaroori contacts (hamesha ring)", style = MaterialTheme.typography.titleMedium)
            if (favs.isEmpty()) Text("Abhi koi contact nahi chuna.")
            favs.forEach { (h, n) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f))
                    TextButton(onClick = { store.removeFavourite(h); favs = store.favNames() }) { Text("Hatao") }
                }
            }
            Button(onClick = {
                pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
            }) { Text("+ Contact chuno") }

            Text("Meri favourite jagahein", style = MaterialTheme.typography.titleMedium)
            if (places.isEmpty()) Text("Paas ki jagah screen mein Favourite dabao.")
            places.forEach { fp ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(fp.name, Modifier.weight(1f))
                    TextButton(onClick = { openNavigation(this@MainActivity, fp.lat, fp.lng) }) { Text("Raasta") }
                    TextButton(onClick = { places = places - fp; store.saveFavPlaces(places) }) { Text("Hatao") }
                }
            }
        }
    }
}
