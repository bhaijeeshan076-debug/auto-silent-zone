package com.autosilentzone

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import java.util.UUID

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onResume() {
        super.onResume()
        // Agar zone hat chuka hai ya manual silent ka waqt nikal gaya, to atka hua silent hata do
        val st = Store(this)
        val act = st.activeZone
        if (act == ManualSilent.NAME && !ManualSilent.isOn(this)) ManualSilent.stop(this)
        else if (act != null && act != ManualSilent.NAME && st.zones().none { it.name == act }) SilentController.exitZone(this)
        // Permission baad mein di ho to bhi geofence/reminder sahi se lag jayein
        try { Geofences.register(this) } catch (_: Exception) {}
        try { PrayerReminders.scheduleAll(this) } catch (_: Exception) {}
        tick++
    }

    private val locPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pinSpot("") else toast(tr("Location permission is needed to add a zone", "ज़ोन जोड़ने के लिए लोकेशन अनुमति चाहिए", "Zone jodne ke liye location permission chahiye"))
    }

    /** Ek tap: abhi ki location se zone ban jata hai (naam khali ho to apne aap, jaise "Masjid 1"). */
    private fun pinSpot(name: String) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) { locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION); return }
        toast(tr("Getting your location...", "लोकेशन ले रहे हैं...", "Location le rahe hain..."))
        val client = LocationServices.getFusedLocationProviderClient(this)
        val fail = { toast(tr("Location not found. Turn on GPS and try again.", "लोकेशन नहीं मिली। GPS चालू करके फिर कोशिश करें।", "Location nahi mili. GPS on karke dobara try karo.")) }
        try {
            client.getCurrentLocation(com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (loc != null) saveZone(name, loc)
                    else client.lastLocation.addOnSuccessListener { l2 -> if (l2 != null) saveZone(name, l2) else fail() }
                }
                .addOnFailureListener { fail() }
        } catch (_: SecurityException) { fail() }
    }

    private fun saveZone(name: String, loc: android.location.Location) {
        val s = Store(this)
        val zones = s.zones()
        val near = zones.firstOrNull {
            val r = FloatArray(1); android.location.Location.distanceBetween(it.lat, it.lng, loc.latitude, loc.longitude, r); r[0] < 30f
        }
        if (near != null) { toast(tr("A zone already exists here: ", "यहाँ पहले से ज़ोन है: ", "Yahan pehle se zone hai: ") + near.name); return }
        val place = FaithPacks.selected(s).firstOrNull()?.place() ?: tr("Zone", "ज़ोन", "Zone")
        val finalName = name.trim().ifEmpty { "$place ${zones.size + 1}" }
        s.saveZones(zones + Zone(UUID.randomUUID().toString(), finalName, loc.latitude, loc.longitude, 100f))
        s.addLog("Zone bana: $finalName (100 m)")
        try { Geofences.register(this) } catch (_: Exception) {}
        tick++
        val warn = ArrayList<String>()
        if (android.os.Build.VERSION.SDK_INT >= 29 && androidx.core.content.ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) warn += "Location: Allow all the time"
        if (!SilentController.canControl(this)) warn += "Do Not Disturb access"
        toast(tr("Zone added: ", "ज़ोन जुड़ गया: ", "Zone ban gaya: ") + finalName + " (100 m)" +
            (if (warn.isEmpty()) "" else "\n" + tr("Now allow in Setup: ", "अब सेटअप में दें: ", "Ab Setup mein do: ") + warn.joinToString(", ")))
    }

    private fun toggleManual() {
        if (ManualSilent.isOn(this)) { ManualSilent.stop(this); toast(tr("Manual silent stopped", "मैनुअल साइलेंट बंद", "Manual silent band")) }
        else if (!SilentController.canControl(this)) toast(tr("First allow Do Not Disturb access in Setup", "पहले सेटअप में डू नॉट डिस्टर्ब एक्सेस दें", "Pehle Setup mein Do Not Disturb access do"))
        else { ManualSilent.start(this); toast(tr("Silent for 1 hour", "1 घंटे के लिए साइलेंट", "1 ghante ke liye silent")) }
        tick++
    }

    private fun toast(msg: String) = android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.load(this)
        window.statusBarColor = android.graphics.Color.parseColor("#0B0B0D")
        window.navigationBarColor = android.graphics.Color.parseColor("#0B0B0D")
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        val store = Store(this)
        setContent {
            MaterialTheme {
                var splash by rememberSaveable { mutableStateOf(true) }
                var ready by remember { mutableStateOf(store.faiths.isNotEmpty()) }
                if (splash) SplashScreen { splash = false }
                else if (!ready) Onboarding(store) { ready = true } else {
                    var page by remember { mutableStateOf("home") }
                    BackHandler(page != "home") { page = "home" }
                    if (page == "home") HomeScreen(
                        store, tick,
                        onSetup = { page = "settings" },
                        onNearby = { startActivity(Intent(this@MainActivity, NearbyActivity::class.java)) },
                        onPrayer = { startActivity(Intent(this@MainActivity, PrayerActivity::class.java)) },
                        onManual = { toggleManual() },
                        onQibla = { startActivity(Intent(this@MainActivity, QiblaActivity::class.java)) },
                        onTimings = { startActivity(Intent(this@MainActivity, FaithActivity::class.java)) },
                        onFestivals = { startActivity(Intent(this@MainActivity, FestivalsActivity::class.java)) },
                        onPin = { pinSpot(it) }
                    ) else SetupScreen(store)
                }
            }
        }
    }

    @Composable
    fun SetupScreen(store: Store) {
        var zones by remember(tick) { mutableStateOf(store.zones()) }
        var name by remember { mutableStateOf("") }
        var threshold by remember { mutableStateOf(store.threshold.toFloat()) }
        var win by remember { mutableStateOf(store.windowMin) }
        val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        var favs by remember(tick) { mutableStateOf(store.favNames()) }
        var places by remember(tick) { mutableStateOf(store.favPlaces()) }
        val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val uri = r.data?.data
            if (r.resultCode == RESULT_OK && uri != null) {
                contentResolver.query(
                    uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) { store.addFavourite(c.getString(1) ?: "Contact", c.getString(0) ?: ""); favs = store.favNames() }
                }
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Auto Silent Zone", style = MaterialTheme.typography.headlineSmall)
            LanguageChips(store)
            HealthCheck(this@MainActivity, tick)
            EventLog(store, tick)
            Text(store.activeZone?.let { "🔕 Silent on hai: $it" } ?: tr("No zone active right now","अभी कोई ज़ोन चालू नहीं है","Abhi koi zone active nahi"))

            Button(onClick = { startActivity(Intent(this@MainActivity, NearbyActivity::class.java)) }) { Text("📍 " + nearbyLabel(store)) }

            Text(tr("Your packs: ","आपके पैक: ","Aapke pack: ") + FaithPacks.selected(store).joinToString { it.name() })
            TextButton(onClick = { store.faiths = emptySet(); recreate() }) { Text(tr("Change faith","धर्म बदलें","Dharm badlo")) }

            Text(tr("Setup (one time)","सेटअप (एक बार)","Setup (ek baar)"), style = MaterialTheme.typography.titleMedium)
            Button(onClick = {
                perms.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION))
            }) { Text(tr("1. Location permission","1. लोकेशन अनुमति","1. Location permission")) }
            Button(onClick = {
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    // Android 11+ par "Allow all the time" sirf app ki settings se milta hai
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName")))
                } else perms.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
            }) { Text(tr("2. Location: Allow all the time","2. लोकेशन: हमेशा अनुमति दें","2. Location: Allow all the time")) }
            Button(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }) {
                Text(tr("3. Do Not Disturb access","3. डू नॉट डिस्टर्ब एक्सेस","3. Do Not Disturb access"))
            }
            Button(onClick = {
                val rm = getSystemService(RoleManager::class.java)
                startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }) { Text(tr("4. Call screening role (for repeat calls)","4. कॉल स्क्रीनिंग (बार-बार कॉल के लिए)","4. Call screening role (repeat-call ke liye)")) }

            Button(onClick = { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
                Text(tr("5. Battery: set to Unrestricted", "5. बैटरी: Unrestricted करें", "5. Battery: Unrestricted karo"))
            }
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                Button(onClick = {
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:$packageName")))
                }) { Text(tr("6. Allow exact alarms", "6. सटीक अलार्म की अनुमति दें", "6. Exact alarms allow karo")) }
            }

            Text("Repeat call: ${threshold.toInt()} call pe ring (${win} min ke andar)")
            Slider(value = threshold, onValueChange = { threshold = it; store.threshold = it.toInt() }, valueRange = 2f..10f, steps = 7)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(5, 10, 15, 30).forEach { mm ->
                    FilterChip(selected = win == mm, onClick = { win = mm; store.windowMin = mm }, label = { Text("$mm min") })
                }
            }

            Text(tr("Add a zone (where you are now)","ज़ोन जोड़ें (जहाँ अभी हैं)","Zone add karo (abhi jahan ho wahan)"), style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(name, { name = it }, label = { Text(tr("Name", "नाम", "Naam") + " (" + exampleName(store) + ")") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                try {
                    LocationServices.getFusedLocationProviderClient(this@MainActivity).lastLocation.addOnSuccessListener { loc ->
                        if (loc != null && name.isNotBlank()) {
                            zones = zones + Zone(UUID.randomUUID().toString(), name.trim(), loc.latitude, loc.longitude)
                            store.saveZones(zones); Geofences.register(this@MainActivity); name = ""
                        }
                    }
                } catch (_: SecurityException) {}
            }) { Text(tr("Make zone here","यहाँ ज़ोन बनाएँ","Yahan zone banao")) }

            Text(tr("My zones: radius and rule","मेरे ज़ोन: दायरा और नियम","Meri jagahein: radius aur rule"), style = MaterialTheme.typography.titleMedium)
            zones.forEach { z ->
                ZoneCard(
                    z,
                    onChange = { nz ->
                        zones = zones.map { if (it.id == nz.id) nz else it }
                        store.saveZones(zones)
                        try { Geofences.register(this@MainActivity) } catch (_: Exception) {}
                    },
                    onDelete = {
                        if (store.activeZone == z.name) SilentController.exitZone(this@MainActivity)
                        zones = zones - z; store.saveZones(zones)
                        try { Geofences.register(this@MainActivity) } catch (_: Exception) {}
                    }
                )
            }

            Text(tr("Important contacts (always ring)","ज़रूरी संपर्क (हमेशा रिंग)","Zaroori contacts (hamesha ring)"), style = MaterialTheme.typography.titleMedium)
            if (favs.isEmpty()) Text(tr("No contacts picked yet.","अभी कोई संपर्क नहीं चुना।","Abhi koi contact nahi chuna."))
            favs.forEach { (h, n) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(n, Modifier.weight(1f))
                    TextButton(onClick = { store.removeFavourite(h); favs = store.favNames() }) { Text(tr("Remove","हटाएँ","Hatao")) }
                }
            }
            Button(onClick = {
                pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
            }) { Text(tr("+ Pick contact","+ संपर्क चुनें","+ Contact chuno")) }

            Text(tr("My favourite places","मेरी पसंदीदा जगहें","Meri favourite jagahein"), style = MaterialTheme.typography.titleMedium)
            if (places.isEmpty()) Text(tr("Tap Favourite in Nearby places.","पास की जगह में पसंदीदा दबाएँ।","Paas ki jagah screen mein Favourite dabao."))
            places.forEach { fp ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(fp.name, Modifier.weight(1f))
                    TextButton(onClick = { openNavigation(this@MainActivity, fp.lat, fp.lng) }) { Text(tr("Directions","रास्ता","Raasta")) }
                    TextButton(onClick = { places = places - fp; store.saveFavPlaces(places) }) { Text(tr("Remove","हटाएँ","Hatao")) }
                }
            }
        }
    }
}
