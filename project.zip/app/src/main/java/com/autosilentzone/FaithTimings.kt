package com.autosilentzone

import java.util.Calendar

data class TimingItem(val key: String, val label: String, val time: Long, val fixed: Boolean = false)

/** Islam ke alawa baaki dharmon ke rozana/haftawari waqt. Sooraj ke waqt location se, baaki tay waqt aap badal sakte ho. */
object FaithTimings {
    fun items(s: Store, faith: String, day: Calendar, lat: Double, lng: Double): List<TimingItem> {
        val sunrise = PrayerTimes.sunEvent(day, lat, lng, 0.833, true)
        val sunset = PrayerTimes.sunEvent(day, lat, lng, 0.833, false)
        val dow = day.get(Calendar.DAY_OF_WEEK)
        val midnight = (day.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        fun fixed(key: String, label: String, defMin: Int) = TimingItem(key, label, midnight + s.timeMin(key, defMin) * 60_000L, true)
        fun rel(base: Long, offMin: Int) = if (base < 0) -1L else base + offMin * 60_000L

        return when (faith) {
            "hindu" -> listOf(
                TimingItem("hindu_brahma", tr("Brahma Muhurta", "ब्रह्म मुहूर्त", "Brahma Muhurta"), rel(sunrise, -96)),
                TimingItem("hindu_am", tr("Morning aarti (sunrise)", "प्रभात आरती (सूर्योदय)", "Prabhat aarti (suryoday)"), sunrise),
                TimingItem("hindu_pm", tr("Evening aarti (sunset)", "संध्या आरती (सूर्यास्त)", "Sandhya aarti (suryast)"), sunset)
            )
            "sikh" -> listOf(
                TimingItem("sikh_amrit", tr("Amrit Vela - Nitnem", "अमृत वेला - नितनेम", "Amrit Vela - Nitnem"), rel(sunrise, -120)),
                TimingItem("sikh_rehras", tr("Rehras Sahib (sunset)", "रहरास साहिब (सूर्यास्त)", "Rehras Sahib (suryast)"), sunset),
                fixed("sikh_sohila", tr("Kirtan Sohila (bedtime)", "कीर्तन सोहिला (सोने से पहले)", "Kirtan Sohila (sone se pehle)"), 21 * 60 + 30)
            )
            "christian" -> (if (dow == Calendar.SUNDAY)
                listOf(fixed("chr_service", tr("Sunday service", "रविवार की सभा", "Sunday service"), 9 * 60))
            else emptyList()) +
                listOf(fixed("chr_evening", tr("Evening prayer", "संध्या प्रार्थना", "Sham ki prarthana"), 19 * 60))
            "buddhist" -> listOf(
                TimingItem("bud_am", tr("Morning chanting (sunrise)", "प्रातः पाठ (सूर्योदय)", "Subah ka paath (suryoday)"), sunrise),
                TimingItem("bud_pm", tr("Evening chanting (sunset)", "सायं पाठ (सूर्यास्त)", "Sham ka paath (suryast)"), sunset)
            )
            "jain" -> listOf(
                TimingItem("jain_navkarsi", tr("Navkarsi (48 min after sunrise)", "नवकारसी (सूर्योदय के 48 मिनट बाद)", "Navkarsi (suryoday ke 48 min baad)"), rel(sunrise, 48)),
                TimingItem("jain_chauvihar", tr("Chauvihar (stop food/water at sunset)", "चौविहार (सूर्यास्त पर अन्न-जल बंद)", "Chauvihar (suryast pe khana-paani band)"), sunset)
            )
            "jewish" -> buildList {
                if (dow == Calendar.FRIDAY) add(TimingItem("jew_candle", tr("Shabbat candle lighting", "शब्बत की मोमबत्ती", "Shabbat candle lighting"), rel(sunset, -18)))
                if (dow == Calendar.SATURDAY) add(TimingItem("jew_havdalah", tr("Havdalah (Shabbat ends)", "हवदलाह (शब्बत ख़त्म)", "Havdalah (Shabbat khatam)"), PrayerTimes.sunEvent(day, lat, lng, 8.5, false)))
            }
            else -> emptyList()
        }
    }

    /** Agle 8 din mein har item ka sabse nazdeeki waqt. */
    fun upcoming(s: Store, faith: String, lat: Double, lng: Double): List<TimingItem> {
        val seen = LinkedHashMap<String, TimingItem>()
        for (off in 0..7) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, off) }
            items(s, faith, cal, lat, lng).forEach { if (it.key !in seen && it.time > 0) seen[it.key] = it }
        }
        return seen.values.sortedBy { it.time }
    }
}
