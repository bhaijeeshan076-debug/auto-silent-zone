package com.autosilentzone

import android.Manifest
import android.app.AlarmManager
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private fun granted(ctx: Context, perm: String) =
    ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

/** Test ke liye: kaun si permission mili hai aur kaun si baaki hai. */
@Composable
fun HealthCheck(ctx: Context, tick: Int) {
    val checks = remember(tick) {
        val list = mutableListOf<Pair<String, Boolean>>()
        list += "Location" to granted(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
        list += "Location: Allow all the time" to (Build.VERSION.SDK_INT < 29 || granted(ctx, Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        list += "Do Not Disturb access" to SilentController.canControl(ctx)
        val rm = ctx.getSystemService(RoleManager::class.java)
        list += "Call screening role" to (rm?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true)
        list += "Notifications" to (Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS))
        list += "Battery: Unrestricted" to ((ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName))
        list += "Exact alarms" to (Build.VERSION.SDK_INT < 31 || (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms())
        list
    }
    val s = Store(ctx)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(tr("Self-check", "सेल्फ़-चेक", "Self-check"), style = MaterialTheme.typography.titleMedium)
            checks.forEach { (name, ok) -> Text((if (ok) "\u2705 " else "\u274C ") + name) }
            Text(tr("Zones: ", "ज़ोन: ", "Zones: ") + s.zones().size, style = MaterialTheme.typography.bodySmall)
            Text(
                tr("Fix every \u274C before testing. Battery: Settings > Apps > Auto Silent Zone > Battery > Unrestricted.",
                    "टेस्ट से पहले हर \u274C ठीक करें। बैटरी: सेटिंग्स > ऐप्स > Auto Silent Zone > बैटरी > Unrestricted।",
                    "Test se pehle har \u274C theek karo. Battery: Settings > Apps > Auto Silent Zone > Battery > Unrestricted."),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

/** Aakhri ghatnayein: zone mein aaye/gaye, silent hua ya nahi, call ka faisla. Number save nahi hota. */
@Composable
fun EventLog(store: Store, tick: Int) {
    var refresh by remember { mutableStateOf(0) }
    val lines = remember(tick, refresh) { store.log() }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(tr("Test log", "टेस्ट लॉग", "Test log"), style = MaterialTheme.typography.titleMedium)
                Row {
                    TextButton(onClick = { refresh++ }) { Text(tr("Refresh", "रीफ़्रेश", "Refresh")) }
                    TextButton(onClick = { store.clearLog(); refresh++ }) { Text(tr("Clear", "साफ़ करें", "Clear")) }
                }
            }
            if (lines.isEmpty()) Text(tr("No events yet.", "अभी कोई घटना नहीं।", "Abhi koi event nahi."), style = MaterialTheme.typography.bodySmall)
            lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
