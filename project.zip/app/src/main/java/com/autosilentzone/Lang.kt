package com.autosilentzone

import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/** Bhasha: "hn" = Hinglish, "en" = English, "hi" = Hindi. */
object AppLang {
    var code: String by mutableStateOf("hn")
    fun load(ctx: Context) { code = Store(ctx).lang }
}

fun tr(en: String, hi: String, hn: String): String = when (AppLang.code) {
    "en" -> en
    "hi" -> hi
    else -> hn
}

fun FaithPack.name(): String = when (id) {
    "islam" -> tr("Islam", "इस्लाम", "Islam")
    "hindu" -> tr("Hindu", "हिंदू", "Hindu")
    "christian" -> tr("Christian", "ईसाई", "Christian")
    "sikh" -> tr("Sikh", "सिख", "Sikh")
    "buddhist" -> tr("Buddhist", "बौद्ध", "Buddhist")
    "jain" -> tr("Jain", "जैन", "Jain")
    "jewish" -> tr("Jewish", "यहूदी", "Jewish")
    else -> tr("Custom", "कस्टम", "Custom")
}

fun FaithPack.place(): String = when (id) {
    "islam" -> tr("Mosque", "मस्जिद", "Masjid")
    "hindu" -> tr("Temple", "मंदिर", "Mandir")
    "christian" -> tr("Church", "चर्च", "Church")
    "sikh" -> tr("Gurudwara", "गुरुद्वारा", "Gurudwara")
    "buddhist" -> tr("Monastery", "विहार", "Vihara")
    "jain" -> tr("Jain temple", "देरासर", "Derasar")
    "jewish" -> tr("Synagogue", "सिनेगॉग", "Synagogue")
    else -> tr("My place", "मेरी जगह", "Meri jagah")
}

@Composable
fun LanguageChips(store: Store) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("hn" to "Hinglish", "en" to "English", "hi" to "हिन्दी").forEach { (c, l) ->
            FilterChip(selected = AppLang.code == c, onClick = { AppLang.code = c; store.lang = c }, label = { Text(l) })
        }
    }
}

/** Chune hue dharm ke hisaab se shabd. Ek dharm chuna ho to uski jagah ka naam (Masjid/Mandir...). */
private fun singlePack(store: Store): FaithPack? =
    FaithPacks.selected(store).filter { it.id != "custom" }.let { if (it.size == 1) it[0] else null }

fun nearbyLabel(store: Store): String {
    val p = singlePack(store) ?: return tr("Nearby places", "पास की जगह", "Paas ki jagah")
    return tr("Nearby ${p.place()}", "पास में: ${p.place()}", "Paas mein ${p.place()}")
}

fun exampleName(store: Store): String = when (FaithPacks.selected(store).firstOrNull()?.id) {
    "islam" -> "Jama Masjid"
    "hindu" -> "Shiv Mandir"
    "christian" -> "St. Mary's Church"
    "sikh" -> "Gurudwara Sahib"
    "buddhist" -> "Buddha Vihara"
    "jain" -> "Jain Derasar"
    "jewish" -> "Synagogue"
    else -> tr("My place", "मेरी जगह", "Meri jagah")
}
