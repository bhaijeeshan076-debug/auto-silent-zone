package com.autosilentzone

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.android.gms.location.LocationServices
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class PrayerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Screen() } }
    }

    @Composable
    fun Screen() {
        val s = remember { Store(this) }
        var loc by remember { mutableStateOf(if (s.hasLocation) s.lat to s.lng else null) }
        var method by remember { mutableStateOf(s.method) }
        var asr by remember { mutableStateOf(s.asr) }
        var lead by remember { mutableStateOf(s.prayerLead) }
        var on by remember { mutableStateOf(s.prayerOn) }
        val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
        val fmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

        LaunchedEffect(Unit) {
            try {
                LocationServices.getFusedLocationProviderClient(this@PrayerActivity).lastLocation.addOnSuccessListener {
                    if (it != null) {
                        s.lat = it.latitude; s.lng = it.longitude
                        loc = it.latitude to it.longitude
                        PrayerReminders.scheduleAll(this@PrayerActivity)
                    }
                }
            } catch (_: SecurityException) {}
        }

        val times = remember(loc, method, asr) {
            loc?.let { PrayerTimes.compute(Calendar.getInstance(), it.first, it.second, method, asr) }
        }
        val next = remember(loc, method, asr) { loc?.let { PrayerTimes.next(it.first, it.second, method, asr) } }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Namaz ke waqt", style = MaterialTheme.typography.headlineSmall)

            if (times == null) {
                Text("Location nahi mili. Setup mein location permission do aur GPS on karke dobara kholo.")
            } else {
                if (next != null) {
                    val mins = ((next.time - System.currentTimeMillis()) / 60000).toInt()
                    Text("Agli namaz: ${next.label} (${fmt.format(Date(next.time))}) \u00B7 ${mins / 60} ghante ${mins % 60} min mein",
                        style = MaterialTheme.typography.titleMedium)
                }
                Text("Reminder ke liye switch on karo", style = MaterialTheme.typography.labelMedium)
                times.forEach { p ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(p.label, Modifier.weight(1f), fontWeight = if (p.key == next?.key) FontWeight.Bold else FontWeight.Normal)
                        Text(if (p.time > 0) fmt.format(Date(p.time)) else "--")
                        if (p.key != "sunrise") {
                            Switch(
                                checked = p.key in on, modifier = Modifier.padding(start = 12.dp),
                                onCheckedChange = { v ->
                                    on = if (v) on + p.key else on - p.key
                                    s.prayerOn = on
                                    if (v && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    PrayerReminders.scheduleAll(this@PrayerActivity)
                                }
                            )
                        } else Spacer(Modifier.width(64.dp))
                    }
                }

                Text("Hisaab ka tareeka", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrayerTimes.methodNames.forEachIndexed { i, n ->
                        FilterChip(selected = method == i, onClick = { method = i; s.method = i; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(n) })
                    }
                }
                Text("Asr", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = asr == 2, onClick = { asr = 2; s.asr = 2; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text("Hanafi") })
                    FilterChip(selected = asr == 1, onClick = { asr = 1; s.asr = 1; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text("Shafi") })
                }
                Text("Reminder kitna pehle", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Waqt pe", 5 to "5 min", 10 to "10 min").forEach { (m, l) ->
                        FilterChip(selected = lead == m, onClick = { lead = m; s.prayerLead = m; PrayerReminders.scheduleAll(this@PrayerActivity) }, label = { Text(l) })
                    }
                }
                Text("Yeh waqt hisaab se nikalte hain, aapki masjid ke waqt se 1-3 minute alag ho sakte hain. Jamaat ka waqt masjid mein hi poochein.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
