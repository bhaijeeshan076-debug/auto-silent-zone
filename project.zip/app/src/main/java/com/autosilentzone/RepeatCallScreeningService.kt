package com.autosilentzone

import android.telecom.Call
import android.telecom.CallScreeningService

/**
 * Zone ke andar: ek hi number se N call (window ke andar) aaye -> phone ring.
 * Favourite number -> pehli call se hi ring.
 * Isko chalane ke liye user ko app ko "Call screening app" role dena hoga (MainActivity mein button hai).
 */
class RepeatCallScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        // Hamesha call allow karte hain (block nahi); sirf ringer control karte hain.
        respondToCall(details, CallResponse.Builder().build())

        val s = Store(this)
        if (s.activeZone == null) return
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) return
        val number = details.handle?.schemeSpecificPart ?: return   // private number track nahi hota

        val isFav = Store.hash(number) in s.favourites()
        val count = s.recordCall(number, System.currentTimeMillis())
        if (isFav || count >= s.threshold) {
            s.addLog("Call: " + (if (isFav) "zaroori contact" else "$count/${s.threshold} baar") + " -> RING")
            SilentController.ringNow(this)
        } else {
            s.addLog("Call: $count/${s.threshold} baar -> silent")
            SilentController.backToSilent(this)
        }
    }
}
