package com.autosilentzone

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

data class Prayer(val key: String, val label: String, val time: Long)   // time = millis, -1 agar nikal na sake

/** Namaz ke waqt, bina internet, sirf location + date se (standard astronomical formula). */
object PrayerTimes {
    val methodNames = listOf("Karachi", "MWL", "ISNA")
    private val angles = listOf(18.0 to 18.0, 18.0 to 17.0, 15.0 to 15.0)   // (fajr, isha)

    private fun dr(d: Double) = Math.toRadians(d)
    private fun rd(r: Double) = Math.toDegrees(r)
    private fun fixAngle(a: Double) = (a % 360.0).let { if (it < 0) it + 360.0 else it }
    private fun fixHour(h: Double) = (h % 24.0).let { if (it < 0) it + 24.0 else it }

    private fun julian(y0: Int, m0: Int, d: Int): Double {
        var y = y0; var m = m0
        if (m <= 2) { y -= 1; m += 12 }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + d + b - 1524.5
    }

    private class Sun(val decl: Double, val eqt: Double)

    private fun sun(jd: Double): Sun {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(dr(g)) + 0.020 * sin(dr(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(rd(atan2(cos(dr(e)) * sin(dr(l)), cos(dr(l)))) / 15.0)
        var eqt = q / 15.0 - ra
        if (eqt > 12) eqt -= 24.0
        if (eqt < -12) eqt += 24.0
        return Sun(rd(asin(sin(dr(e)) * sin(dr(l)))), eqt)
    }

    private fun midDay(jd: Double, t: Double) = fixHour(12 - sun(jd + t).eqt)

    private fun angleTime(jd: Double, lat: Double, angle: Double, t: Double, ccw: Boolean): Double {
        val decl = sun(jd + t).decl
        val noon = midDay(jd, t)
        val x = (-sin(dr(angle)) - sin(dr(decl)) * sin(dr(lat))) / (cos(dr(decl)) * cos(dr(lat)))
        if (x < -1.0 || x > 1.0) return Double.NaN
        val tt = rd(acos(x)) / 15.0
        return noon + if (ccw) -tt else tt
    }

    private fun asrTime(jd: Double, lat: Double, factor: Int, t: Double): Double {
        val decl = sun(jd + t).decl
        val angle = -rd(atan(1.0 / (factor + tan(dr(abs(lat - decl))))))
        return angleTime(jd, lat, angle, t, false)
    }

    /** asrFactor: 1 = Shafi/Maliki/Hanbali, 2 = Hanafi */
    fun compute(day: Calendar, lat: Double, lng: Double, method: Int, asrFactor: Int): List<Prayer> {
        val base = (day.clone() as Calendar).apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val tz = TimeZone.getDefault().getOffset(base.timeInMillis + 12 * 3600_000L) / 3600_000.0
        val jd = julian(base.get(Calendar.YEAR), base.get(Calendar.MONTH) + 1, base.get(Calendar.DAY_OF_MONTH)) - lng / (15.0 * 24.0)
        val (fa, ia) = angles[method.coerceIn(0, angles.size - 1)]

        fun ms(h: Double, extraMin: Int = 0): Long =
            if (h.isNaN()) -1L else base.timeInMillis + ((h + tz - lng / 15.0 + extraMin / 60.0) * 3600_000.0).toLong()

        return listOf(
            Prayer("fajr", "Fajr", ms(angleTime(jd, lat, fa, 5.0 / 24, true))),
            Prayer("sunrise", "Suraj nikalna", ms(angleTime(jd, lat, 0.833, 6.0 / 24, true))),
            Prayer("dhuhr", "Zuhr", ms(midDay(jd, 12.0 / 24), 1)),
            Prayer("asr", "Asr", ms(asrTime(jd, lat, asrFactor, 13.0 / 24))),
            Prayer("maghrib", "Maghrib", ms(angleTime(jd, lat, 0.833, 18.0 / 24, false), 2)),
            Prayer("isha", "Isha", ms(angleTime(jd, lat, ia, 18.0 / 24, false)))
        )
    }

    /** Ab ke baad ki agli namaz (sunrise ko chhodkar), aaj ya kal. */
    fun next(lat: Double, lng: Double, method: Int, asrFactor: Int): Prayer? {
        val now = System.currentTimeMillis()
        for (off in 0..1) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, off) }
            compute(cal, lat, lng, method, asrFactor).filter { it.key != "sunrise" && it.time > now }
                .minByOrNull { it.time }?.let { return it }
        }
        return null
    }
}
