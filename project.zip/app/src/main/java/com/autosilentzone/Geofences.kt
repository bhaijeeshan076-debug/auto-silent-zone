package com.autosilentzone

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.*

object Geofences {
    private fun pi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, GeofenceReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE   // geofencing ke liye MUTABLE zaroori
    )

    /** Saari zones dobara register karta hai (max 100 geofence limit ka dhyan rakho). */
    @SuppressLint("MissingPermission")
    fun register(ctx: Context) {
        val client = LocationServices.getGeofencingClient(ctx)
        val zones = Store(ctx).zones().take(100)
        client.removeGeofences(pi(ctx))
        if (zones.isEmpty()) return
        val list = zones.map {
            Geofence.Builder().setRequestId(it.id).setCircularRegion(it.lat, it.lng, it.radius)
                .setExpirationDuration(Geofence.NEVER_EXPIRE)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
                .build()
        }
        val req = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(list).build()
        client.addGeofences(req, pi(ctx))
    }
}

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val ev = GeofencingEvent.fromIntent(intent) ?: return
        if (ev.hasError()) return
        when (ev.geofenceTransition) {
            Geofence.GEOFENCE_TRANSITION_ENTER, Geofence.GEOFENCE_TRANSITION_DWELL -> {
                val id = ev.triggeringGeofences?.firstOrNull()?.requestId
                val zone = Store(ctx).zones().firstOrNull { it.id == id }
                Store(ctx).addLog("Zone ENTER: ${zone?.name ?: "?"}")
                zone?.let { SilentController.enterZone(ctx, it) }
            }
            Geofence.GEOFENCE_TRANSITION_EXIT -> {
                val id = ev.triggeringGeofences?.firstOrNull()?.requestId
                val s = Store(ctx)
                val z = s.zones().firstOrNull { it.id == id }
                s.addLog("Zone EXIT: ${z?.name ?: "?"}")
                if (z == null || z.name == s.activeZone) SilentController.exitZone(ctx)
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) { try { Geofences.register(ctx) } catch (_: Exception) {}
        try { PrayerReminders.scheduleAll(ctx) } catch (_: Exception) {} }
}
