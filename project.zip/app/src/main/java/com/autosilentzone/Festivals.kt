package com.autosilentzone

import android.icu.util.HebrewCalendar
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.time.temporal.TemporalAdjusters

data class Fest(val date: LocalDate, val name: String, val faith: String)

/** Tyohaar. Islam, Christian, Jewish aur chand ke din hisaab se; baaki dharmon ki tareekhein table se (2027 tak). */
object Festivals {
    private val zone: ZoneId get() = ZoneId.systemDefault()
    private val hijriMonths = listOf(
        "Muharram", "Safar", "Rabi al-Awwal", "Rabi al-Thani", "Jumada al-Awwal", "Jumada al-Thani",
        "Rajab", "Shaban", "Ramadan", "Shawwal", "Dhul Qadah", "Dhul Hijjah"
    )

    private fun hijri(d: LocalDate, adj: Int): HijrahDate = HijrahDate.from(d.plusDays(adj.toLong()))

    fun hijriText(s: Store): String {
        val h = hijri(LocalDate.now(), s.hijriAdj)
        return "${h.get(ChronoField.DAY_OF_MONTH)} ${hijriMonths[h.get(ChronoField.MONTH_OF_YEAR) - 1]} ${h.get(ChronoField.YEAR)} AH"
    }

    /** -1 = abhi Ramzan chal raha hai, warna Ramzan shuru hone mein kitne din. */
    fun daysToRamadan(s: Store): Int {
        val today = LocalDate.now()
        if (hijri(today, s.hijriAdj).get(ChronoField.MONTH_OF_YEAR) == 9) return -1
        for (i in 1..400) {
            val h = hijri(today.plusDays(i.toLong()), s.hijriAdj)
            if (h.get(ChronoField.MONTH_OF_YEAR) == 9 && h.get(ChronoField.DAY_OF_MONTH) == 1) return i
        }
        return 999
    }

    private fun islamic(s: Store, from: LocalDate, to: LocalDate): List<Fest> {
        val out = mutableListOf<Fest>()
        var d = from
        while (!d.isAfter(to)) {
            val h = hijri(d, s.hijriAdj)
            val m = h.get(ChronoField.MONTH_OF_YEAR)
            val day = h.get(ChronoField.DAY_OF_MONTH)
            val name = when {
                m == 1 && day == 1 -> "Islamic New Year"
                m == 1 && day == 10 -> "Ashura"
                m == 3 && day == 12 -> "Mawlid (Eid Milad-un-Nabi)"
                m == 9 && day == 1 -> "Ramzan begins"
                m == 10 && day == 1 -> "Eid al-Fitr"
                m == 12 && day == 9 -> "Day of Arafah"
                m == 12 && day == 10 -> "Eid al-Adha (Bakrid)"
                else -> null
            }
            if (name != null) out += Fest(d, name, "islam")
            d = d.plusDays(1)
        }
        return out
    }

    private fun easter(y: Int): LocalDate {
        val a = y % 19
        val b = y / 100
        val c = y % 100
        val d = b / 4
        val e = b % 4
        val f = (b + 8) / 25
        val g = (b - f + 1) / 3
        val h = (19 * a + b - d - g + 15) % 30
        val i = c / 4
        val k = c % 4
        val l = (32 + 2 * e + 2 * i - h - k) % 7
        val m = (a + 11 * h + 22 * l) / 451
        val month = (h + l - 7 * m + 114) / 31
        val day = ((h + l - 7 * m + 114) % 31) + 1
        return LocalDate.of(y, month, day)
    }

    private fun christian(from: LocalDate, to: LocalDate): List<Fest> {
        val out = mutableListOf<Fest>()
        for (y in from.year..to.year) {
            val e = easter(y)
            val advent = LocalDate.of(y, 12, 24).with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY)).minusWeeks(3)
            out += listOf(
                Fest(LocalDate.of(y, 1, 6), "Epiphany", "christian"),
                Fest(e.minusDays(46), "Ash Wednesday", "christian"),
                Fest(e.minusDays(7), "Palm Sunday", "christian"),
                Fest(e.minusDays(2), "Good Friday", "christian"),
                Fest(e, "Easter", "christian"),
                Fest(e.plusDays(39), "Ascension Day", "christian"),
                Fest(e.plusDays(49), "Pentecost", "christian"),
                Fest(LocalDate.of(y, 11, 1), "All Saints' Day", "christian"),
                Fest(advent, "Advent begins", "christian"),
                Fest(LocalDate.of(y, 12, 25), "Christmas", "christian")
            )
        }
        return out
    }

    private fun jewish(from: LocalDate, to: LocalDate): List<Fest> {
        val out = mutableListOf<Fest>()
        val hy0 = HebrewCalendar().apply { timeInMillis = from.atStartOfDay(zone).toInstant().toEpochMilli() }
            .get(android.icu.util.Calendar.YEAR)
        for (hy in hy0..hy0 + 1) {
            fun g(month: Int, day: Int): LocalDate =
                Instant.ofEpochMilli(HebrewCalendar(hy, month, day).timeInMillis).atZone(zone).toLocalDate()
            out += listOf(
                Fest(g(HebrewCalendar.TISHRI, 1), "Rosh Hashanah", "jewish"),
                Fest(g(HebrewCalendar.TISHRI, 10), "Yom Kippur", "jewish"),
                Fest(g(HebrewCalendar.TISHRI, 15), "Sukkot", "jewish"),
                Fest(g(HebrewCalendar.TISHRI, 23), "Simchat Torah", "jewish"),
                Fest(g(HebrewCalendar.KISLEV, 25), "Hanukkah begins", "jewish"),
                Fest(g(HebrewCalendar.ADAR, 14), "Purim", "jewish"),
                Fest(g(HebrewCalendar.NISAN, 15), "Passover (Pesach)", "jewish"),
                Fest(g(HebrewCalendar.SIVAN, 6), "Shavuot", "jewish")
            )
        }
        return out
    }

    private fun moon(faith: String, fullName: String, newName: String?, from: LocalDate, to: LocalDate): List<Fest> {
        val out = mutableListOf<Fest>()
        val end = to.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        fun scan(target: Double, name: String) {
            var t = from.atStartOfDay(zone).toInstant().toEpochMilli()
            while (true) {
                val p = Astro.nextPhase(t, target)
                if (p > end) break
                out += Fest(Instant.ofEpochMilli(p).atZone(zone).toLocalDate(), name, faith)
                t = p + 24 * 3600_000L
            }
        }
        scan(180.0, fullName)
        if (newName != null) scan(0.0, newName)
        return out
    }

    // faith, tareekh, naam. Panchang/parampara ke hisaab se +-1 din farq ho sakta hai. Table 2027 tak hai.
    private val table = listOf(
        Triple("hindu", "2027-01-15", "Makar Sankranti / Pongal"),
        Triple("hindu", "2027-02-11", "Vasant Panchami"),
        Triple("hindu", "2027-03-06", "Maha Shivratri"),
        Triple("hindu", "2027-03-21", "Holika Dahan"),
        Triple("hindu", "2027-03-22", "Holi"),
        Triple("hindu", "2027-04-07", "Gudi Padwa / Ugadi / Chaitra Navratri"),
        Triple("hindu", "2027-04-15", "Ram Navami"),
        Triple("hindu", "2027-04-20", "Hanuman Jayanti"),
        Triple("hindu", "2027-05-09", "Akshaya Tritiya"),
        Triple("hindu", "2027-07-05", "Jagannath Rath Yatra"),
        Triple("hindu", "2027-07-18", "Guru Purnima"),
        Triple("hindu", "2027-08-17", "Raksha Bandhan"),
        Triple("hindu", "2027-08-25", "Krishna Janmashtami"),
        Triple("hindu", "2027-09-04", "Ganesh Chaturthi"),
        Triple("hindu", "2027-09-30", "Sharad Navratri begins"),
        Triple("hindu", "2027-10-09", "Dussehra (Vijayadashami)"),
        Triple("hindu", "2027-10-18", "Karva Chauth"),
        Triple("hindu", "2027-10-27", "Dhanteras"),
        Triple("hindu", "2027-10-29", "Diwali"),
        Triple("hindu", "2027-10-30", "Govardhan Puja"),
        Triple("hindu", "2027-10-31", "Bhai Dooj"),
        Triple("hindu", "2027-12-09", "Gita Jayanti"),
        Triple("sikh", "2027-03-14", "Nanakshahi New Year"),
        Triple("sikh", "2027-04-14", "Vaisakhi"),
        Triple("sikh", "2027-10-29", "Bandi Chhor Divas"),
        Triple("sikh", "2027-11-14", "Guru Nanak Gurpurab"),
        Triple("jain", "2027-04-19", "Mahavir Jayanti"),
        Triple("jain", "2027-08-28", "Paryushan begins"),
        Triple("jain", "2027-09-04", "Samvatsari (Day of Forgiveness)"),
        Triple("jain", "2027-10-29", "Diwali (Mahavir Nirvan)"),
        Triple("jain", "2027-10-30", "Jain New Year"),
        Triple("buddhist", "2026-12-08", "Bodhi Day"),
        Triple("buddhist", "2027-02-15", "Nirvana Day"),
        Triple("buddhist", "2027-02-20", "Magha Puja"),
        Triple("buddhist", "2027-05-20", "Buddha Purnima (Vesak)"),
        Triple("buddhist", "2027-07-18", "Asalha Puja (Dhamma Day)")
    )

    fun upcoming(s: Store, from: LocalDate = LocalDate.now(), days: Int = 366): List<Fest> {
        val to = from.plusDays(days.toLong())
        val f = s.faiths
        val out = mutableListOf<Fest>()
        if ("islam" in f) out += islamic(s, from, to)
        if ("christian" in f) out += christian(from, to)
        if ("jewish" in f) out += jewish(from, to)
        if ("hindu" in f) out += moon("hindu", "Purnima (full moon)", "Amavasya (new moon)", from, to)
        if ("buddhist" in f) out += moon("buddhist", "Poya / Uposatha (full moon)", "Uposatha (new moon)", from, to)
        for ((faith, date, name) in table) if (faith in f) out += Fest(LocalDate.parse(date), name, faith)
        return out.filter { !it.date.isBefore(from) && !it.date.isAfter(to) }.sortedBy { it.date }
    }
}
